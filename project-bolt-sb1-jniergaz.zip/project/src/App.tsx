import { useState, useCallback } from 'react';
import { ScanLine, Snowflake, Wallet, MessageCircle, Sprout } from 'lucide-react';
import { AppProvider, useApp } from '@/lib/context';
import type { Tab } from '@/lib/types';
import { type Certificate, type Transaction } from '@/lib/types';
import AuthScreen from '@/components/AuthScreen';
import Header from '@/components/Header';
import ScanPanel from '@/components/ScanPanel';
import HubPanel from '@/components/HubPanel';
import IncomePanel from '@/components/IncomePanel';
import IncomeTab from '@/components/IncomeTab';
import ChatPanel from '@/components/ChatPanel';

const TABS: { id: Tab; en: string; hi: string; icon: typeof ScanLine }[] = [
  { id: 'scan', en: 'Scan Crate', hi: 'क्रेट स्कैन', icon: ScanLine },
  { id: 'hub', en: 'Cold Rooms', hi: 'कोल्ड स्टोर', icon: Snowflake },
  { id: 'income', en: 'My Income', hi: 'मेरी आय', icon: Wallet },
  { id: 'payments', en: 'Khata', hi: 'खाता', icon: Wallet },
  { id: 'chat', en: 'Assistant', hi: 'सहायक', icon: MessageCircle },
];

function Shell() {
  const { state, dispatch } = useApp();
  const [tab, setTab] = useState<Tab>('scan');
  const [pendingCert, setPendingCert] = useState<Certificate | null>(null);

  const handleFindColdRoom = useCallback((cert: Certificate) => {
    setPendingCert(cert);
    setTab('hub');
  }, []);

  const handleListForSale = useCallback((cert: Certificate) => {
    const txn: Transaction = {
      id: `TXN-${Date.now()}`,
      type: 'sale',
      description: `${cert.cropName} Sale — ${cert.weightKg} kg (Grade ${cert.grade})`,
      amount: Math.round(cert.weightKg * cert.mandiRate * 0.92),
      status: 'escrow',
      utr: `ESC-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toISOString().slice(0, 10),
      cropName: cert.cropName,
      weightKg: cert.weightKg,
      grade: cert.grade,
    };
    dispatch({ type: 'LOCK_DEAL', txn });
    setTab('payments');
  }, [dispatch]);

  const handleLockDeal = useCallback((txn: Transaction) => {
    dispatch({ type: 'LOCK_DEAL', txn });
    setTab('payments');
  }, [dispatch]);

  if (!state.farmer) return <AuthScreen />;

  const maxW = state.viewMode === 'desktop' ? 'max-w-6xl' : 'max-w-md';
  const gridCols = state.viewMode === 'desktop' ? 'lg:grid lg:grid-cols-2 lg:gap-6' : '';

  return (
    <div className="min-h-screen bg-parchment-100">
      <Header />
      <main className={`${maxW} mx-auto px-4 py-4 pb-28`}>
        <div className={gridCols}>
          {state.viewMode === 'desktop' ? (
            <>
              <div className="space-y-4">
                {tab === 'scan' && <ScanPanel onFindColdRoom={handleFindColdRoom} onListForSale={handleListForSale} />}
                {tab === 'hub' && <HubPanel pendingCert={pendingCert} />}
                {(tab === 'income' || tab === 'payments' || tab === 'chat') && (
                  <div className="card p-8 text-center text-mute">
                    <Sprout size={40} className="mx-auto mb-3 text-forest-300" />
                    <p className="font-display text-lg font-bold text-forest-700">FreshGrid Dashboard</p>
                    <p className="text-sm mt-1">Use the tabs below to navigate. Selected panel is shown on the right.</p>
                  </div>
                )}
              </div>
              <div className="space-y-4">
                {tab === 'scan' && <div className="card p-8 text-center text-mute"><p className="font-display text-lg font-bold text-forest-700">Recent Activity</p><p className="text-sm mt-1">Scan a crate to see your quality certificate here.</p></div>}
                {tab === 'hub' && <div className="card p-8 text-center text-mute"><p className="font-display text-lg font-bold text-forest-700">Booking Summary</p><p className="text-sm mt-1">Select a cold room to book a slot.</p></div>}
                {tab === 'income' && <IncomeTab onLockDeal={handleLockDeal} />}
                {tab === 'payments' && <IncomePanel />}
                {tab === 'chat' && <ChatPanel />}
              </div>
            </>
          ) : (
            <>
              {tab === 'scan' && <ScanPanel onFindColdRoom={handleFindColdRoom} onListForSale={handleListForSale} />}
              {tab === 'hub' && <HubPanel pendingCert={pendingCert} />}
              {tab === 'income' && <IncomeTab onLockDeal={handleLockDeal} />}
              {tab === 'payments' && <IncomePanel />}
              {tab === 'chat' && <ChatPanel />}
            </>
          )}
        </div>
      </main>

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-20 bg-parchment-100/95 backdrop-blur-md border-t border-parchment-300">
        <div className={`${maxW} mx-auto grid grid-cols-5`}>
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex flex-col items-center gap-0.5 py-2.5 transition-all ${active ? 'text-forest-600' : 'text-mute hover:text-forest-700'}`}>
                <Icon size={20} className={active ? 'scale-110' : ''} style={{ transition: 'transform 0.2s' }} />
                <span className="text-[10px] font-bold leading-tight text-center">{state.lang === 'hi' ? t.hi : t.en}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}
