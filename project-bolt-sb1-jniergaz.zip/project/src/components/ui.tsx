import type { ReactNode } from 'react';
import { X } from 'lucide-react';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  titleHi?: string;
  children: ReactNode;
  maxWidth?: string;
}

export function Modal({ open, onClose, title, titleHi, children, maxWidth = 'max-w-md' }: ModalProps) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-forest-900/50 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className={`relative w-full ${maxWidth} bg-parchment-100 border border-parchment-300 rounded-t-3xl sm:rounded-2xl shadow-pop max-h-[92vh] overflow-y-auto scrollbar-none animate-slide-up sm:animate-scale-in`}>
        {(title || titleHi) && (
          <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 bg-parchment-100/95 backdrop-blur-md border-b border-parchment-300 rounded-t-3xl sm:rounded-t-2xl">
            <div>
              {title && <h2 className="font-display text-xl font-bold text-forest-700">{title}</h2>}
              {titleHi && <p className="text-xs text-mute">{titleHi}</p>}
            </div>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-parchment-300 text-mute transition" aria-label="Close">
              <X size={20} />
            </button>
          </div>
        )}
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

export function Stamp({ text, className = '' }: { text: string; className?: string }) {
  return (
    <div className={`inline-flex items-center justify-center px-3 py-1.5 border-2 border-gold-400 text-gold-600 font-display font-bold text-xs uppercase tracking-wider rotate-[-12deg] bg-parchment-50/60 ${className}`}>
      {text}
    </div>
  );
}

export function VerifiedSeal({ label = 'Verified' }: { label?: string }) {
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-50 text-profit border border-green-200 text-[11px] font-bold">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg>
      {label}
    </span>
  );
}

export function QRPlaceholder({ size = 140, label = 'Scan to Pay' }: { size?: number; label?: string }) {
  const cells = 21;
  const cellSize = size / cells;
  const pattern: boolean[] = [];
  for (let i = 0; i < cells * cells; i++) pattern.push(Math.random() > 0.5);
  const finder = (r: number, c: number) =>
    (r < 7 && c < 7) || (r < 7 && c >= cells - 7) || (r >= cells - 7 && c < 7);
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative bg-white p-3 rounded-xl border-2 border-parchment-300 shadow-card" style={{ width: size + 24, height: size + 24 }}>
        <svg width={size} height={size}>
          <rect width={size} height={size} fill="white" />
          {pattern.map((on, i) => {
            const r = Math.floor(i / cells), c = i % cells;
            if (finder(r, c)) return null;
            if (!on) return null;
            return <rect key={i} x={c * cellSize} y={r * cellSize} width={cellSize} height={cellSize} fill="#1A1A1A" />;
          })}
          {[[0, 0], [0, cells - 7], [cells - 7, 0]].map(([r, c], i) => (
            <g key={i}>
              <rect x={c * cellSize} y={r * cellSize} width={7 * cellSize} height={7 * cellSize} fill="#1A1A1A" />
              <rect x={(c + 1) * cellSize} y={(r + 1) * cellSize} width={5 * cellSize} height={5 * cellSize} fill="white" />
              <rect x={(c + 2) * cellSize} y={(r + 2) * cellSize} width={3 * cellSize} height={3 * cellSize} fill="#1A1A1A" />
            </g>
          ))}
        </svg>
      </div>
      <span className="text-xs font-semibold text-mute">{label}</span>
    </div>
  );
}
