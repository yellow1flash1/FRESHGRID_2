import { useState, useCallback } from 'react';
import { ShieldCheck, TrendingUp, Snowflake, CreditCard, QrCode, Loader2, CheckCircle2, ArrowDownToLine, ArrowUpFromLine, Receipt, Landmark, Printer } from 'lucide-react';
import { useApp } from '@/lib/context';
import { type Transaction, type LedgerEntry, type TxnStatus } from '@/lib/types';
import { uid, genUTR } from '@/lib/store';
import { formatINR } from '@/lib/income';
import { Modal, QRPlaceholder, Stamp, VerifiedSeal } from './ui';

const UPI_APPS = ['GPay', 'PhonePe', 'Paytm', 'BHIM'];

export default function IncomePanel() {
  const { state, dispatch } = useApp();
  const farmer = state.farmer!;
  const [showBuyerQR, setShowBuyerQR] = useState(false);
  const [processingPayout, setProcessingPayout] = useState(false);
  const [payoutDone, setPayoutDone] = useState(false);
  const [showUPI, setShowUPI] = useState(false);
  const [upiApp, setUpiApp] = useState('GPay');
  const [upiPaying, setUpiPaying] = useState(false);
  const [upiDone, setUpiDone] = useState(false);
  const [filter, setFilter] = useState<'all' | TxnStatus>('all');
  const [receipt, setReceipt] = useState<LedgerEntry | null>(null);

  const escrowTxn = state.transactions.find((t) => t.status === 'escrow');

  const simulateBuyerScan = useCallback(() => {
    if (!escrowTxn) return;
    setProcessingPayout(true);
    setTimeout(() => {
      const utr = genUTR();
      const ledger: LedgerEntry = {
        id: uid('led'), type: 'sale', description: `Escrow Released — ${escrowTxn.cropName ?? ''} ${escrowTxn.weightKg ?? ''} kg`,
        gross: escrowTxn.amount, net: escrowTxn.amount, status: 'settled', utr, date: new Date().toISOString().slice(0, 10),
        cropName: escrowTxn.cropName, weightKg: escrowTxn.weightKg, grade: escrowTxn.grade,
        deductions: [],
      };
      dispatch({ type: 'RELEASE_ESCROW', txnId: escrowTxn.id, ledger });
      setProcessingPayout(false);
      setPayoutDone(true);
      setTimeout(() => { setPayoutDone(false); setShowBuyerQR(false); }, 2500);
    }, 2200);
  }, [escrowTxn, dispatch]);

  const duesAmount = state.wallet.coldCredit;

  const payUPI = useCallback(() => {
    setUpiPaying(true);
    const utr = genUTR();
    setTimeout(() => {
      dispatch({ type: 'CLEAR_DUES', amount: duesAmount, utr });
      setUpiPaying(false); setUpiDone(true);
      setTimeout(() => { setUpiDone(false); setShowUPI(false); }, 1800);
    }, 2000);
  }, [dispatch, duesAmount]);

  const filteredLedger = state.ledger.filter((l) => filter === 'all' || l.status === filter);

  return (
    <div className="space-y-4 animate-fade-up">
      <h2 className="font-display text-lg font-bold text-forest-700">Payments & Khata (भुगतान और खाता)</h2>

      {/* Wallet Summary Header */}
      <div className="card-forest p-5">
        <div className="grid grid-cols-3 gap-3">
          <div>
            <div className="flex items-center gap-1 text-gold-300 text-[10px] font-bold uppercase tracking-wider mb-1"><TrendingUp size={12} /> Earned</div>
            <div className="text-xl font-extrabold text-parchment-100">{formatINR(state.wallet.totalEarned)}</div>
            <div className="text-[10px] text-forest-300">This Season</div>
          </div>
          <div>
            <div className="flex items-center gap-1 text-gold-300 text-[10px] font-bold uppercase tracking-wider mb-1"><ShieldCheck size={12} /> Escrow</div>
            <div className="text-xl font-extrabold text-gold-300">{formatINR(state.wallet.inEscrow)}</div>
            <div className="text-[10px] text-forest-300">Pending Delivery</div>
          </div>
          <div>
            <div className="flex items-center gap-1 text-gold-300 text-[10px] font-bold uppercase tracking-wider mb-1"><Snowflake size={12} /> Credit</div>
            <div className="text-xl font-extrabold text-parchment-100">{formatINR(state.wallet.coldCredit)}</div>
            <div className="text-[10px] text-forest-300">Cold Storage Due</div>
          </div>
        </div>
        <div className="mt-4 pt-3 border-t border-forest-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Landmark size={16} className="text-gold-300" />
            <div>
              <p className="text-xs text-parchment-100 font-semibold">{farmer.bankName} •••• {farmer.bankAcc}</p>
              <p className="text-[10px] text-forest-300">UPI: {farmer.upiId}</p>
            </div>
          </div>
          <VerifiedSeal label="NPCI Aadhaar Seeding" />
        </div>
      </div>

      {/* Buyer Escrow Release */}
      {escrowTxn && (
        <div className="card p-4 border-2 border-gold-300">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-9 h-9 rounded-lg bg-gold-50 border border-gold-200 flex items-center justify-center"><ShieldCheck size={18} className="text-gold-600" /></div>
            <div>
              <h3 className="font-display font-bold text-forest-700">Buyer Escrow Order</h3>
              <p className="text-xs text-mute">Release funds on delivery scan</p>
            </div>
          </div>
          <div className="p-3 rounded-lg bg-parchment-50 border border-parchment-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-bold text-sm text-forest-700">{escrowTxn.cropName} • {escrowTxn.weightKg} kg</p>
                <p className="text-[11px] text-mute">Reliance Fresh / Mother Dairy FPO Pool</p>
              </div>
              <div className="text-right">
                <div className="text-xl font-extrabold text-gold-600">{formatINR(escrowTxn.amount)}</div>
                <span className="chip-warn">In Escrow</span>
              </div>
            </div>
          </div>
          <div className="flex gap-2 mt-3">
            <button onClick={() => setShowBuyerQR(true)} className="btn-ghost flex-1 flex items-center justify-center gap-2">
              <QrCode size={17} /> Show Delivery QR
            </button>
            <button onClick={simulateBuyerScan} disabled={processingPayout || payoutDone}
              className="btn-brand flex-1 flex items-center justify-center gap-2">
              {processingPayout ? <Loader2 size={17} className="animate-spin-slow" /> : payoutDone ? <CheckCircle2 size={17} /> : <ArrowDownToLine size={17} />}
              {processingPayout ? 'Processing…' : payoutDone ? 'Released!' : 'Simulate QR Scan & Release'}
            </button>
          </div>
        </div>
      )}

      {/* Cold Storage Dues */}
      {state.wallet.coldCredit > 0 && (
        <div className="card p-4">
          <div className="flex items-center gap-2 mb-3">
            <Snowflake size={18} className="text-forest-600" />
            <h3 className="font-display font-bold text-forest-700">Cold Storage Credit Due</h3>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-sm text-mute">Pay via UPI or Kisan Credit Card</p>
            <span className="text-xl font-extrabold text-alert">{formatINR(state.wallet.coldCredit)}</span>
          </div>
          <button onClick={() => setShowUPI(true)} className="btn-primary mt-3 flex items-center justify-center gap-2">
            <CreditCard size={17} /> Pay Dues via UPI
          </button>
        </div>
      )}

      {/* Ledger */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-display text-base font-bold text-forest-700">Digital Parchi Ledger (किसान बही-खाता)</h3>
        </div>
        <div className="flex gap-2 mb-3 overflow-x-auto scrollbar-none">
          {(['all', 'settled', 'escrow', 'credit'] as const).map((f) => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap capitalize transition ${filter === f ? 'bg-forest-600 text-parchment-100' : 'bg-parchment-200 text-mute border border-parchment-300'}`}>{f}</button>
          ))}
        </div>
        <div className="space-y-2">
          {filteredLedger.map((l) => (
            <div key={l.id} className="card p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                    l.type === 'sale' ? 'bg-green-50 text-profit' : l.type === 'cold' ? 'bg-forest-50 text-forest-600' : 'bg-gold-50 text-gold-600'
                  }`}>
                    {l.type === 'sale' ? <ArrowUpFromLine size={16} /> : l.type === 'cold' ? <Snowflake size={16} /> : <Receipt size={16} />}
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-sm text-forest-700 truncate">{l.description}</p>
                    <p className="text-[11px] text-mute">{l.date} • UTR: {l.utr}</p>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className={`font-extrabold text-sm ${l.net >= 0 ? 'text-profit' : 'text-alert'}`}>{formatINR(l.net)}</div>
                  <span className={`chip ${l.status === 'settled' ? 'chip-profit' : l.status === 'escrow' ? 'chip-warn' : 'chip-alert'}`}>{l.status}</span>
                </div>
              </div>
              <button onClick={() => setReceipt(l)} className="mt-2 flex items-center gap-1 text-xs font-bold text-forest-600 hover:underline">
                <Receipt size={13} /> View Parchi / Receipt
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Buyer QR Modal */}
      <Modal open={showBuyerQR} onClose={() => !processingPayout && !payoutDone && setShowBuyerQR(false)} title="Delivery QR for Buyer" titleHi="बायर के लिए QR">
        {escrowTxn && (
          <div className="space-y-4 text-center">
            {payoutDone ? (
              <div className="py-8 animate-scale-in">
                <CheckCircle2 size={72} className="mx-auto text-profit" />
                <h3 className="font-display text-xl font-bold text-forest-700 mt-3">₹{escrowTxn.amount.toLocaleString('en-IN')} Released!</h3>
                <p className="text-sm text-mute mt-1">UPI Payout processed successfully</p>
                <div className="mt-4 p-3 rounded-lg bg-forest-50 border border-forest-100 text-left">
                  <div className="flex justify-between text-xs">
                    <span className="text-mute">UTR / Reference:</span>
                    <span className="font-bold text-forest-700">{genUTR()}</span>
                  </div>
                  <div className="flex justify-between text-xs mt-1">
                    <span className="text-mute">Credited to:</span>
                    <span className="font-bold text-forest-700">{farmer.upiId}</span>
                  </div>
                  <div className="flex justify-between text-xs mt-1">
                    <span className="text-mute">Status:</span>
                    <span className="font-bold text-profit">SUCCESS</span>
                  </div>
                </div>
              </div>
            ) : processingPayout ? (
              <div className="py-12">
                <Loader2 size={56} className="mx-auto animate-spin-slow text-forest-500" />
                <h3 className="font-display text-lg font-bold text-forest-700 mt-4">Processing UPI Payout…</h3>
                <p className="text-sm text-mute mt-1">NPCI routing in progress</p>
                <div className="mt-4 flex items-center justify-center gap-2 text-xs text-mute">
                  <div className="w-2 h-2 rounded-full bg-forest-500 animate-pulse-soft" />
                  Connecting to NPCI gateway…
                </div>
              </div>
            ) : (
              <>
                <p className="text-sm text-mute">Show this QR to the buyer at delivery. They scan it to confirm receipt — funds release instantly to your UPI.</p>
                <div className="flex justify-center"><QRPlaceholder size={180} label="Delivery Confirmation QR" /></div>
                <div className="card-warm p-3 text-left">
                  <div className="flex justify-between text-sm"><span className="text-mute">Order:</span><span className="font-bold text-forest-700">{escrowTxn.cropName} • {escrowTxn.weightKg} kg</span></div>
                  <div className="flex justify-between text-sm mt-1"><span className="text-mute">Escrow Amount:</span><span className="font-bold text-gold-600">{formatINR(escrowTxn.amount)}</span></div>
                  <div className="flex justify-between text-sm mt-1"><span className="text-mute">Buyer:</span><span className="font-bold text-forest-700">Reliance Fresh FPO Pool</span></div>
                </div>
                <button onClick={simulateBuyerScan} className="btn-brand flex items-center justify-center gap-2">
                  <ArrowDownToLine size={17} /> Simulate Buyer QR Scan & Release
                </button>
              </>
            )}
          </div>
        )}
      </Modal>

      {/* UPI Payment Modal */}
      <Modal open={showUPI} onClose={() => !upiPaying && !upiDone && setShowUPI(false)} title="UPI Payment" titleHi="UPI भुगतान">
        <div className="space-y-4">
          {upiDone ? (
            <div className="py-8 text-center animate-scale-in">
              <CheckCircle2 size={64} className="mx-auto text-profit" />
              <h3 className="font-display text-lg font-bold text-forest-700 mt-3">Payment Successful</h3>
              <p className="text-sm text-mute mt-1">{formatINR(duesAmount)} paid via {upiApp}</p>
              <p className="text-xs text-mute mt-2">UTR: {genUTR()}</p>
            </div>
          ) : upiPaying ? (
            <div className="py-12 text-center">
              <Loader2 size={48} className="mx-auto animate-spin-slow text-forest-500" />
              <p className="text-sm text-mute mt-3">Processing via {upiApp}…</p>
            </div>
          ) : (
            <>
              <div className="flex justify-center"><QRPlaceholder size={150} label={`Pay ${formatINR(duesAmount)}`} /></div>
              <div className="text-center">
                <p className="text-xs text-mute">Scan with any UPI app or select below</p>
                <p className="font-bold text-lg text-forest-700 mt-1">{formatINR(duesAmount)}</p>
                <p className="text-xs text-mute">Cold Storage Credit Due</p>
              </div>
              <div>
                <label className="label">Select UPI App</label>
                <div className="grid grid-cols-4 gap-2">
                  {UPI_APPS.map((a) => (
                    <button key={a} onClick={() => setUpiApp(a)}
                      className={`py-2 rounded-lg border text-xs font-bold transition ${upiApp === a ? 'border-forest-500 bg-forest-50 text-forest-700' : 'border-parchment-300 text-mute'}`}>{a}</button>
                  ))}
                </div>
              </div>
              <button onClick={payUPI} className="btn-primary flex items-center justify-center gap-2">
                <CreditCard size={17} /> Pay {formatINR(duesAmount)} via {upiApp}
              </button>
            </>
          )}
        </div>
      </Modal>

      {/* Receipt Modal */}
      <Modal open={!!receipt} onClose={() => setReceipt(null)} title="Official e-Receipt" titleHi="आधिकारिक ई-रसीद">
        {receipt && (
          <div className="space-y-4">
            <div className="card-warm p-5 border-2 border-gold-300 relative print-receipt">
              <div className="absolute top-3 right-3"><Stamp text="Settled" /></div>
              <div className="text-center border-b border-gold-200 pb-3 mb-3">
                <h3 className="font-display text-xl font-bold text-forest-700">FreshGrid FPO</h3>
                <p className="text-[11px] text-gold-600 font-serif">Official Mandi & FPO e-Receipt</p>
                <p className="text-[10px] text-mute mt-0.5">FPO Reg No: HR-SNP-4092 • GSTIN: 06AABCF1234M1Z5</p>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-mute">Farmer:</span><span className="font-bold text-forest-700">{farmer.name}</span></div>
                <div className="flex justify-between"><span className="text-mute">Kisan ID:</span><span className="font-bold text-forest-700">{farmer.kisanId}</span></div>
                <div className="flex justify-between"><span className="text-mute">Receipt No:</span><span className="font-bold text-forest-700">#{receipt.id.slice(-6).toUpperCase()}</span></div>
                <div className="flex justify-between"><span className="text-mute">Date:</span><span className="font-bold text-forest-700">{receipt.date}</span></div>
                {receipt.cropName && <div className="flex justify-between"><span className="text-mute">Crop:</span><span className="font-bold text-forest-700">{receipt.cropName}</span></div>}
                {receipt.weightKg && <div className="flex justify-between"><span className="text-mute">Weight:</span><span className="font-bold text-forest-700">{receipt.weightKg} kg</span></div>}
                {receipt.grade && <div className="flex justify-between"><span className="text-mute">Grade:</span><span className="font-bold text-forest-700">{receipt.grade}</span></div>}
                {receipt.hubName && <div className="flex justify-between"><span className="text-mute">Cold Room:</span><span className="font-bold text-forest-700">{receipt.hubName}</span></div>}
              </div>
              <div className="border-t border-gold-200 mt-3 pt-3">
                <div className="flex justify-between text-sm font-bold"><span>Gross Amount:</span><span className="text-forest-700">{formatINR(receipt.gross)}</span></div>
                {receipt.deductions.map((d, i) => (
                  <div key={i} className="flex justify-between text-xs text-alert mt-1"><span>{d.label}:</span><span>-{formatINR(d.amount)}</span></div>
                ))}
                <div className="flex justify-between text-base font-extrabold mt-2 pt-2 border-t border-gold-200"><span className="text-forest-700">Net Payout:</span><span className="text-profit">{formatINR(receipt.net)}</span></div>
                <div className="flex justify-between text-xs mt-2"><span className="text-mute">UTR No:</span><span className="font-bold text-forest-700">{receipt.utr}</span></div>
              </div>
            </div>
            <button className="btn-ghost flex items-center justify-center gap-2" onClick={() => window.print()}>
              <Printer size={17} /> Download / Print Receipt
            </button>
          </div>
        )}
      </Modal>
    </div>
  );
}
