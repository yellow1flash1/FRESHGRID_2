import { useState, useCallback, useEffect, useRef } from 'react';
import { Send, Loader2, Sparkles, Mic, Volume2 } from 'lucide-react';
import { useApp } from '@/lib/context';
import { uid } from '@/lib/store';
import { COLD_HUBS, type ChatMessage } from '@/lib/types';
import { formatINR } from '@/lib/income';

const SUGGESTIONS = [
  'How do I scan a crate?',
  'Find cheapest cold room near me',
  'How is my income calculated?',
  'What does Grade A / Grade C mean?',
  'How does UPI Escrow payout work?',
];

function generateReply(message: string, state: ReturnType<typeof useApp>['state']): string {
  const q = message.toLowerCase();
  const wallet = state.wallet;
  const hubs = COLD_HUBS;
  const cheapest = [...hubs].sort((a, b) => a.pricePerCrateDay - b.pricePerCrateDay)[0];
  const escrowTxn = state.transactions.find((t) => t.status === 'escrow');

  if (q.includes('scan') || q.includes('crate') || q.includes('स्कैन')) {
    return "To scan a crate:\n1. Open the Scan Crate tab (क्रेट स्कैन)\n2. Select your crop from the grid\n3. Enter the crate weight in kg\n4. Tap 'Start Camera' to use your phone camera, or 'Simulate Crate Scan' if no camera is available\n5. The AI grades your crate in ~2.5 seconds and generates an official Quality Certificate with a Batch ID\n\nYou can then reserve a cold room or list the crate for buyer escrow sale directly from the certificate.";
  }
  if (q.includes('cold') || q.includes('room') || q.includes('storage') || q.includes('cheapest') || q.includes('कोल्ड')) {
    return `Here are the cold rooms near ${state.farmer?.village ?? 'you'}:\n\n1. Sunrise Solar Cold Hub — ${hubs[0].distanceKm} km, ₹${hubs[0].pricePerCrateDay}/crate/day, ${hubs[0].slotsFree} slots free, ${hubs[0].tempC}°C\n2. Gram Seva Cold Room — ${hubs[1].distanceKm} km, ₹${hubs[1].pricePerCrateDay}/crate/day, ${hubs[1].slotsFree} slots free\n3. Kisan FPO Chiller — ${hubs[2].distanceKm} km, ₹${hubs[2].pricePerCrateDay}/crate/day, ${hubs[2].slotsFree} slots free\n\nCheapest option: ${cheapest.name} at ₹${cheapest.pricePerCrateDay}/crate/day. You can pay now via UPI or use FPO Credit (pay later from your harvest sale).`;
  }
  if (q.includes('income') || q.includes('calculate') || q.includes('आय') || q.includes('₹')) {
    return `Your income estimate works like this:\n\nWithout FreshGrid (traditional mandi): You lose ~38% to spoilage, pay 6% mandi commission, and bear full individual transport. For 1000 kg Tomato at ₹32/kg, you'd net about ₹${formatINR(1000 * 32 * 0.56 - 4000)}.\n\nWith FreshGrid: Cold room reduces spoilage to 8%, you get pooled FPO transport (shared cost), and you sell direct to buyers at full price. Same 1000 kg nets about ₹${formatINR(1000 * 32 * 0.92 - 540 - 1500 - 960)}.\n\nThat's typically a +70% income difference! Use the My Income tab to adjust your crop, weight, and price.\n\nYour current season: Total earned ${formatINR(wallet.totalEarned)}, in escrow ${formatINR(wallet.inEscrow)}.`;
  }
  if (q.includes('grade') || q.includes('quality') || q.includes('ग्रेड')) {
    return "FreshGrid grades crates into three levels:\n\n• Grade A (Export/Retail Quality): Score 75+, shelf life 36+ hours. Best for direct B2B marketplace sales and buyer escrow. Commands premium price.\n\n• Grade B (Local Market Quality): Moderate score. Best split into fractional crates and stored at a micro-cold hub for local retail.\n\n• Grade C (Process/Rescue Quality): Under 36 hours shelf life. Routed to flash rescue sales for ketchup, puree, and dehydration plants. Lower price but zero waste.\n\nThe AI determines grade from ripeness, bruising, uniformity, and spoilage risk detected in your photo.";
  }
  if (q.includes('escrow') || q.includes('upi') || q.includes('payout') || q.includes('payment') || q.includes('भुगतान')) {
    const e = escrowTxn ? `You currently have ${formatINR(escrowTxn.amount)} in buyer escrow (${escrowTxn.cropName}, ${escrowTxn.weightKg} kg). ` : '';
    return `UPI Escrow works as follows:\n\n1. When you list a crate for buyer escrow sale, the buyer's payment is held securely in escrow — not released until delivery is confirmed.\n${e}\n2. At delivery, show the Delivery QR to the buyer. They scan it to confirm receipt.\n3. Funds release instantly to your linked UPI account (${state.farmer?.upiId ?? 'kishanlal@sbi'}) with a UTR reference number.\n4. The settled amount moves from 'In Escrow' to 'Total Earned' and appears in your Digital Parchi ledger.\n\n100% secure — no middleman, no waiting for mandi clearance.`;
  }
  if (q.includes('hello') || q.includes('hi') || q.includes('namaste') || q.includes('नमस्ते')) {
    return `Namaste ${state.farmer?.name ?? 'Kisan ji'}! I'm your FreshGrid assistant. I can help you with scanning crates, finding cold rooms, understanding your income, or releasing escrow payments. What would you like to know?`;
  }
  return `I can help you with:\n• Scanning crates and quality grading\n• Finding and booking cold rooms\n• Income estimation and comparison\n• UPI escrow payouts and khata ledger\n• Grade A / B / C meaning\n\nAsk me any of these, or tap a suggestion chip below. Your current escrow balance is ${formatINR(wallet.inEscrow)}.`;
}

export default function ChatPanel() {
  const { state, dispatch } = useApp();
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [listening, setListening] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [state.chat, sending]);

  const send = useCallback((text: string) => {
    const trimmed = text.trim();
    if (!trimmed || sending) return;
    setInput('');
    const userMsg: ChatMessage = { id: uid('msg'), role: 'user', content: trimmed, createdAt: new Date().toISOString() };
    dispatch({ type: 'ADD_CHAT', msg: userMsg });
    setSending(true);
    setTimeout(() => {
      const reply = generateReply(trimmed, state);
      const botMsg: ChatMessage = { id: uid('msg'), role: 'assistant', content: reply, createdAt: new Date().toISOString() };
      dispatch({ type: 'ADD_CHAT', msg: botMsg });
      setSending(false);
    }, 900 + Math.random() * 600);
  }, [sending, dispatch, state]);

  const toggleVoice = () => {
    if (listening) { setListening(false); return; }
    setListening(true);
    setTimeout(() => {
      setListening(false);
      send('How do I scan a crate?');
    }, 2500);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-280px)] min-h-[400px] animate-fade-up">
      <div className="card flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-parchment-300 bg-forest-50">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-forest-600 text-gold-300 flex items-center justify-center"><Sparkles size={20} /></div>
              <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-profit border-2 border-parchment-100" />
            </div>
            <div>
              <h3 className="font-display font-bold text-forest-700 leading-tight">Kisan Assistant</h3>
              <p className="text-[11px] text-profit font-semibold">Online — FPO & Agri-Expert AI</p>
            </div>
          </div>
          <span className="text-[10px] text-mute font-semibold">किसान सहायक</span>
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-none">
          {state.chat.map((m) => (
            <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-up`}>
              <div className={`max-w-[85%] px-3.5 py-2.5 rounded-2xl text-sm whitespace-pre-line ${m.role === 'user' ? 'bg-forest-600 text-parchment-100 rounded-br-md' : 'bg-parchment-200 border border-parchment-300 rounded-bl-md'}`}>
                {m.content}
              </div>
            </div>
          ))}
          {sending && (
            <div className="flex justify-start">
              <div className="bg-parchment-200 border border-parchment-300 rounded-2xl rounded-bl-md px-4 py-3 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-forest-400 animate-pulse-soft" />
                <span className="w-2 h-2 rounded-full bg-forest-400 animate-pulse-soft" style={{ animationDelay: '0.2s' }} />
                <span className="w-2 h-2 rounded-full bg-forest-400 animate-pulse-soft" style={{ animationDelay: '0.4s' }} />
              </div>
            </div>
          )}
        </div>

        {/* Suggestions */}
        {state.chat.length <= 1 && (
          <div className="px-4 pb-2 flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <button key={s} onClick={() => send(s)} className="chip-forest hover:bg-forest-100 transition">{s}</button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="p-3 border-t border-parchment-300">
          <div className="flex gap-2">
            <button onClick={toggleVoice}
              className={`w-12 h-12 rounded-xl flex items-center justify-center transition shrink-0 ${listening ? 'bg-alert text-white animate-pulse-soft' : 'bg-forest-50 border border-forest-100 text-forest-600 hover:bg-forest-100'}`}
              aria-label="Ask by voice">
              {listening ? <Volume2 size={20} /> : <Mic size={20} />}
            </button>
            <input className="input flex-1" placeholder="Ask me anything…" value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send(input)} disabled={sending} />
            <button className="btn-primary w-12 h-12 p-0 flex items-center justify-center shrink-0" onClick={() => send(input)} disabled={sending || !input.trim()}>
              {sending ? <Loader2 size={18} className="animate-spin-slow" /> : <Send size={18} />}
            </button>
          </div>
          {listening && <p className="mt-2 text-xs text-alert font-semibold flex items-center gap-1.5"><Volume2 size={13} /> Listening… Speak now (बोलकर पूछें)</p>}
        </div>
      </div>
    </div>
  );
}
