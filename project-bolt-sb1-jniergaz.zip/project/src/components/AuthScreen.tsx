import { useState } from 'react';
import { Sprout, Phone, Lock, ShieldCheck, User, MapPin, CreditCard, CheckCircle2, ChevronDown, Eye, EyeOff, Loader2, Sparkles } from 'lucide-react';
import { useApp } from '@/lib/context';
import { DEMO_FARMER, uid } from '@/lib/store';
import { STATES, DISTRICTS, type FarmerProfile } from '@/lib/types';
import { VerifiedSeal } from './ui';

type Mode = 'login' | 'register';

export default function AuthScreen() {
  const { dispatch } = useApp();
  const [mode, setMode] = useState<Mode>('login');
  const [loading, setLoading] = useState(false);

  // Login fields
  const [mobile, setMobile] = useState('');
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);

  // Registration fields
  const [name, setName] = useState('');
  const [regMobile, setRegMobile] = useState('');
  const [state, setState] = useState('Haryana');
  const [district, setDistrict] = useState('Sonipat');
  const [village, setVillage] = useState('');
  const [idType, setIdType] = useState<FarmerProfile['idType']>('PM-Kisan');
  const [kisanId, setKisanId] = useState('');
  const [idScanning, setIdScanning] = useState(false);
  const [idVerified, setIdVerified] = useState(false);
  const [upiId, setUpiId] = useState('');
  const [upiVerifying, setUpiVerifying] = useState(false);
  const [upiVerified, setUpiVerified] = useState(false);
  const [upiName, setUpiName] = useState('');

  const doLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      dispatch({ type: 'LOGIN', farmer: { ...DEMO_FARMER, mobile: mobile || DEMO_FARMER.mobile } });
      setLoading(false);
    }, 800);
  };

  const doDemoLogin = () => {
    setLoading(true);
    setTimeout(() => { dispatch({ type: 'LOGIN', farmer: DEMO_FARMER }); setLoading(false); }, 500);
  };

  const scanId = () => {
    setIdScanning(true);
    setTimeout(() => { setIdScanning(false); setIdVerified(true); }, 1800);
  };

  const verifyUpi = () => {
    if (!upiId.trim()) return;
    setUpiVerifying(true);
    setTimeout(() => {
      setUpiVerifying(false); setUpiVerified(true);
      setUpiName(name.toUpperCase() || 'KISHAN LAL');
    }, 1600);
  };

  const doRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const farmer: FarmerProfile = {
      id: uid('farmer'),
      name: name || 'Kishan Lal',
      mobile: regMobile || '9876543210',
      state, district, village: village || 'Rai',
      fpoId: `HR-SNP-${Math.floor(1000 + Math.random() * 9000)}`,
      kisanId: kisanId || `PMKMY-${Math.floor(10000000 + Math.random() * 90000000)}`,
      idType, idVerified,
      upiId: upiId || 'kishanlal@sbi',
      upiName: upiName || (name.toUpperCase()),
      bankName: 'State Bank of India',
      bankAcc: `${Math.floor(1000 + Math.random() * 9000)}`,
      upiVerified,
      joinedAt: new Date().toISOString().slice(0, 10),
    };
    setTimeout(() => { dispatch({ type: 'LOGIN', farmer }); setLoading(false); }, 800);
  };

  return (
    <div className="min-h-screen flex flex-col bg-parchment-100">
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Emblem Header */}
          <div className="text-center mb-6 animate-fade-up">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-forest-600 text-gold-300 shadow-pop mb-3 relative">
              <Sprout size={40} />
              <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-gold-400 border-2 border-parchment-100 flex items-center justify-center">
                <ShieldCheck size={14} className="text-white" />
              </div>
            </div>
            <h1 className="font-display text-3xl font-bold text-forest-700">FreshGrid</h1>
            <p className="font-serif text-sm text-gold-600 tracking-wide">Scan · Store · Sell</p>
            <p className="text-xs text-mute mt-1">भारत का किसान डिजिटल प्लेटफ़ॉर्म</p>
          </div>

          {/* Mode Toggle */}
          <div className="flex gap-1 p-1 bg-parchment-200 border border-parchment-300 rounded-xl mb-5 animate-fade-up">
            {(['login', 'register'] as Mode[]).map((m) => (
              <button key={m} onClick={() => setMode(m)}
                className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition-all ${mode === m ? 'bg-forest-600 text-parchment-100 shadow-card' : 'text-mute hover:text-forest-700'}`}>
                {m === 'login' ? 'Log In (लॉग इन)' : 'Register (पंजीकरण)'}
              </button>
            ))}
          </div>

          {mode === 'login' ? (
            <form onSubmit={doLogin} className="card p-6 space-y-4 animate-scale-in">
              <div>
                <label className="label" htmlFor="mobile">Mobile Number (मोबाइल नंबर)</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mute font-semibold text-sm">+91</span>
                  <Phone size={18} className="absolute left-12 top-1/2 -translate-y-1/2 text-mute" />
                  <input id="mobile" type="tel" inputMode="numeric" maxLength={10} value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                    placeholder="98765 43210" className="input pl-20" />
                </div>
              </div>
              <div>
                <label className="label" htmlFor="pin">Secure PIN / OTP (पिन)</label>
                <div className="relative">
                  <Lock size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mute" />
                  <input id="pin" type={showPin ? 'text' : 'password'} inputMode="numeric" maxLength={6} value={pin}
                    onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                    placeholder="••••" className="input pl-11 pr-11" />
                  <button type="button" onClick={() => setShowPin(!showPin)} className="absolute right-3 top-1/2 -translate-y-1/2 text-mute hover:text-forest-600">
                    {showPin ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>
              <button type="submit" className="btn-primary flex items-center justify-center gap-2" disabled={loading}>
                {loading ? <Loader2 size={18} className="animate-spin-slow" /> : <ShieldCheck size={18} />}
                {loading ? 'Logging in…' : 'Log In Securely'}
              </button>
              <div className="relative my-2">
                <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-parchment-300" /></div>
                <div className="relative flex justify-center"><span className="bg-parchment-200 px-3 text-xs text-mute font-semibold">OR</span></div>
              </div>
              <button type="button" onClick={doDemoLogin} className="btn-gold flex items-center justify-center gap-2" disabled={loading}>
                <Sparkles size={18} /> Demo Quick Login
              </button>
              <div className="grid grid-cols-3 gap-2 pt-3">
                {[
                  { icon: ShieldCheck, text: '100% Secure UPI Payout', hi: 'सुरक्षित UPI' },
                  { icon: Sprout, text: 'Registered FPO Partner', hi: 'FPO पार्टनर' },
                  { icon: MapPin, text: 'e-NAM & Govt ID Linked', hi: 'e-NAM लिंक्ड' },
                ].map((s, i) => (
                  <div key={i} className="flex flex-col items-center gap-1 p-2 rounded-lg bg-forest-50 text-center">
                    <s.icon size={18} className="text-forest-600" />
                    <span className="text-[9px] font-semibold text-forest-700 leading-tight">{s.text}</span>
                  </div>
                ))}
              </div>
            </form>
          ) : (
            <form onSubmit={doRegister} className="card p-6 space-y-4 animate-scale-in max-h-[60vh] overflow-y-auto scrollbar-none">
              <div>
                <label className="label" htmlFor="name">Full Name (पूरा नाम)</label>
                <div className="relative">
                  <User size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mute" />
                  <input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Kishan Lal" className="input pl-11" required />
                </div>
              </div>
              <div>
                <label className="label" htmlFor="rmobile">Mobile Number (मोबाइल)</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mute font-semibold text-sm">+91</span>
                  <input id="rmobile" type="tel" inputMode="numeric" maxLength={10} value={regMobile}
                    onChange={(e) => setRegMobile(e.target.value.replace(/\D/g, ''))} placeholder="98765 43210" className="input pl-12" required />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label" htmlFor="state">State (राज्य)</label>
                  <div className="relative">
                    <select id="state" value={state} onChange={(e) => { setState(e.target.value); setDistrict(DISTRICTS[e.target.value]?.[0] ?? ''); }}
                      className="input appearance-none pr-9">
                      {STATES.map((s) => <option key={s}>{s}</option>)}
                    </select>
                    <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-mute pointer-events-none" />
                  </div>
                </div>
                <div>
                  <label className="label" htmlFor="dist">District (ज़िला)</label>
                  <div className="relative">
                    <select id="dist" value={district} onChange={(e) => setDistrict(e.target.value)}
                      className="input appearance-none pr-9">
                      {(DISTRICTS[state] ?? []).map((d) => <option key={d}>{d}</option>)}
                    </select>
                    <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-mute pointer-events-none" />
                  </div>
                </div>
              </div>
              <div>
                <label className="label" htmlFor="vill">Village (गाँव)</label>
                <input id="vill" value={village} onChange={(e) => setVillage(e.target.value)} placeholder="Rai" className="input" required />
              </div>
              <div>
                <label className="label" htmlFor="idtype">ID Type (पहचान पत्र)</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Aadhaar', 'KCC', 'PM-Kisan'] as const).map((t) => (
                    <button key={t} type="button" onClick={() => { setIdType(t); setIdVerified(false); }}
                      className={`py-2 rounded-lg border text-xs font-bold transition ${idType === t ? 'border-forest-500 bg-forest-50 text-forest-700' : 'border-parchment-300 text-mute'}`}>{t}</button>
                  ))}
                </div>
              </div>
              <div>
                <label className="label" htmlFor="kid">{idType} Number</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <CreditCard size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mute" />
                    <input id="kid" value={kisanId} onChange={(e) => setKisanId(e.target.value)} placeholder={`${idType}-XXXXXXXX`} className="input pl-11" />
                  </div>
                  <button type="button" onClick={scanId} disabled={idScanning || idVerified}
                    className={`px-4 rounded-lg text-sm font-bold whitespace-nowrap transition flex items-center gap-1.5 ${idVerified ? 'bg-green-50 text-profit border border-green-200' : 'bg-gold-300 text-forest-800 border border-gold-400 hover:bg-gold-400'}`}>
                    {idScanning ? <Loader2 size={16} className="animate-spin-slow" /> : idVerified ? <CheckCircle2 size={16} /> : null}
                    {idScanning ? 'Scanning…' : idVerified ? 'Verified' : 'Scan ID'}
                  </button>
                </div>
                {idVerified && <p className="mt-1.5 text-xs text-profit font-semibold flex items-center gap-1"><CheckCircle2 size={13} /> {idType} verified with Government database</p>}
              </div>
              <div>
                <label className="label" htmlFor="upi">UPI ID for Payout (भुगतान UPI)</label>
                <div className="flex gap-2">
                  <input id="upi" value={upiId} onChange={(e) => setUpiId(e.target.value)} placeholder="kishanlal@sbi" className="input flex-1" />
                  <button type="button" onClick={verifyUpi} disabled={upiVerifying || upiVerified || !upiId.trim()}
                    className={`px-4 rounded-lg text-sm font-bold whitespace-nowrap transition flex items-center gap-1.5 ${upiVerified ? 'bg-green-50 text-profit border border-green-200' : 'bg-forest-50 text-forest-700 border border-forest-100 hover:bg-forest-100'}`}>
                    {upiVerifying ? <Loader2 size={16} className="animate-spin-slow" /> : upiVerified ? <CheckCircle2 size={16} /> : null}
                    {upiVerifying ? 'Verifying…' : upiVerified ? 'Verified' : 'Verify'}
                  </button>
                </div>
                {upiVerified && <p className="mt-1.5 text-xs text-profit font-semibold">Account Holder: {upiName} (State Bank of India — Linked) <VerifiedSeal label="NPCI Aadhaar Seeding Active" /></p>}
              </div>
              <button type="submit" className="btn-primary flex items-center justify-center gap-2" disabled={loading || !idVerified || !upiVerified}>
                {loading ? <Loader2 size={18} className="animate-spin-slow" /> : <Sprout size={18} />}
                {loading ? 'Registering…' : 'Complete Registration'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
