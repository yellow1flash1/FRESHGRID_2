import { useState } from 'react';
import { TrendingUp, TrendingDown, Scale, IndianRupee, Snowflake, Lock, ChevronDown, CheckCircle2 } from 'lucide-react';
import { useApp } from '@/lib/context';
import { CROPS, type Transaction } from '@/lib/types';
import { calcIncome, formatINR } from '@/lib/income';
import { uid } from '@/lib/store';

interface IncomeTabProps { onLockDeal: (txn: Transaction) => void; }

export default function IncomeTab({ onLockDeal }: IncomeTabProps) {
  const { state } = useApp();
  const [cropId, setCropId] = useState('tomato');
  const [kg, setKg] = useState(1000);
  const [price, setPrice] = useState(CROPS[0].mandiRate);
  const [days, setDays] = useState(3);
  const [showBreakdown, setShowBreakdown] = useState<'without' | 'with' | null>('with');

  const crop = CROPS.find((c) => c.id === cropId)!;
  const result = calcIncome(kg, price, days);

  const lockDeal = () => {
    const txn: Transaction = {
      id: uid('txn'),
      type: 'sale',
      description: `${crop.name} Sale Lot — ${kg} kg (Locked at ₹${price}/kg)`,
      amount: result.withFreshGrid,
      status: 'escrow',
      utr: `ESC-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toISOString().slice(0, 10),
      cropName: crop.name,
      weightKg: kg,
    };
    onLockDeal(txn);
  };

  return (
    <div className="space-y-4 animate-fade-up">
      <h2 className="font-display text-lg font-bold text-forest-700">My Income & Estimator (मेरी आय)</h2>

      {/* Inputs */}
      <div className="card p-4 space-y-3">
        <div>
          <label className="label">Select Crop (फसल चुनें)</label>
          <div className="relative">
            <select value={cropId} onChange={(e) => { const c = CROPS.find((x) => x.id === e.target.value)!; setCropId(e.target.value); setPrice(c.mandiRate); }}
              className="input appearance-none pr-9">
              {CROPS.map((c) => <option key={c.id} value={c.id}>{c.emoji} {c.name} — ₹{c.mandiRate}/kg</option>)}
            </select>
            <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-mute pointer-events-none" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label"><span className="flex items-center gap-1.5"><Scale size={13} /> Harvest (kg)</span></label>
            <input type="number" min={50} value={kg} onChange={(e) => setKg(Math.max(0, Number(e.target.value)))} className="input" />
          </div>
          <div>
            <label className="label"><span className="flex items-center gap-1.5"><IndianRupee size={13} /> Price (₹/kg)</span></label>
            <input type="number" min={1} value={price} onChange={(e) => setPrice(Math.max(0, Number(e.target.value)))} className="input" />
          </div>
        </div>
        <div>
          <label className="label"><span className="flex items-center gap-1.5"><Snowflake size={13} /> Storage Days (दिन)</span></label>
          <input type="number" min={1} max={14} value={days} onChange={(e) => setDays(Math.max(1, Number(e.target.value)))} className="input" />
        </div>
      </div>

      {/* Comparison Cards */}
      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => setShowBreakdown(showBreakdown === 'without' ? null : 'without')}
          className="card p-4 text-left border-2 border-red-200 transition hover:shadow-pop">
          <div className="flex items-center gap-1.5 text-alert text-[10px] font-bold uppercase tracking-wider mb-1"><TrendingDown size={13} /> Without FreshGrid</div>
          <div className="text-2xl font-display font-black text-alert">{formatINR(result.withoutFreshGrid)}</div>
          <p className="text-[11px] text-mute mt-1">Traditional Mandi route</p>
          <p className="text-[10px] text-mute mt-0.5">Tap to see breakdown</p>
        </button>
        <button onClick={() => setShowBreakdown(showBreakdown === 'with' ? null : 'with')}
          className="card p-4 text-left border-2 border-forest-200 bg-forest-50/50 transition hover:shadow-pop">
          <div className="flex items-center gap-1.5 text-profit text-[10px] font-bold uppercase tracking-wider mb-1"><TrendingUp size={13} /> With FreshGrid</div>
          <div className="text-2xl font-display font-black text-profit">{formatINR(result.withFreshGrid)}</div>
          <p className="text-[11px] text-mute mt-1">Scan · Store · Sell route</p>
          <p className="text-[10px] text-mute mt-0.5">Tap to see breakdown</p>
        </button>
      </div>

      {/* Breakdown */}
      {showBreakdown && (
        <div className="card p-4 animate-scale-in">
          <h3 className="font-display font-bold text-forest-700 mb-3">{showBreakdown === 'with' ? 'With FreshGrid — Breakdown' : 'Without FreshGrid — Breakdown'}</h3>
          <div className="space-y-2">
            {(showBreakdown === 'with' ? result.withBreakdown : result.withoutBreakdown).map((row, i) => (
              <div key={i} className="flex justify-between items-center py-1.5 border-b border-parchment-300 last:border-0">
                <span className="text-sm text-ink">{row.label}</span>
                <span className={`font-bold text-sm ${row.amount < 0 ? 'text-alert' : 'text-forest-700'}`}>{row.amount < 0 ? '-' : ''}{formatINR(Math.abs(row.amount))}</span>
              </div>
            ))}
            <div className="flex justify-between items-center pt-2 font-extrabold">
              <span className="text-forest-700">Net Income</span>
              <span className={showBreakdown === 'with' ? 'text-profit' : 'text-alert'}>{formatINR(showBreakdown === 'with' ? result.withFreshGrid : result.withoutFreshGrid)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Highlight Banner */}
      <div className="card p-5 bg-forest-600 border-forest-700 text-center">
        <div className="text-3xl font-display font-black text-gold-300">+{result.gainPct}%</div>
        <p className="text-parchment-100 text-sm font-semibold mt-1">Net Income Difference</p>
        <p className="text-gold-300 text-lg font-bold mt-1">+{formatINR(result.gainAbs)} Extra Profit</p>
        <button onClick={lockDeal} className="btn-gold mt-4 flex items-center justify-center gap-2">
          <Lock size={17} /> Lock This Deal & Generate Sale Lot
        </button>
      </div>

      {/* Verified Farmer Income Summary */}
      <div className="card-warm p-4 border border-gold-200">
        <div className="flex items-center gap-2 mb-3">
          <CheckCircle2 size={18} className="text-profit" />
          <h3 className="font-display font-bold text-forest-700">Your Verified Season Summary</h3>
        </div>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex justify-between"><span className="text-mute">Total Earned:</span><span className="font-bold text-profit">{formatINR(state.wallet.totalEarned)}</span></div>
          <div className="flex justify-between"><span className="text-mute">In Escrow:</span><span className="font-bold text-gold-600">{formatINR(state.wallet.inEscrow)}</span></div>
          <div className="flex justify-between"><span className="text-mute">Cold Credit:</span><span className="font-bold text-alert">{formatINR(state.wallet.coldCredit)}</span></div>
          <div className="flex justify-between"><span className="text-mute">Active Lots:</span><span className="font-bold text-forest-700">{state.transactions.filter((t) => t.status === 'escrow').length}</span></div>
        </div>
      </div>
    </div>
  );
}
