import { useState, useCallback } from 'react';
import { MapPin, Navigation, Search, Snowflake, Thermometer, Droplets, Tag, Loader2, CreditCard, CheckCircle2, QrCode, Sun, Zap, Truck } from 'lucide-react';
import { useApp } from '@/lib/context';
import { COLD_HUBS, CROPS, type ColdHub, type Certificate, type Booking, type PayMode, type Transaction, type LedgerEntry } from '@/lib/types';
import { genBay, genGatePass } from '@/lib/scan';
import { uid, genUTR } from '@/lib/store';
import { Modal, QRPlaceholder, Stamp } from './ui';

interface HubPanelProps { pendingCert: Certificate | null; }

const FILTER_PILLS = ['All', 'Solar Powered', '24/7', 'Bulk Dock'];

const tagIcon: Record<string, typeof Sun> = { Solar: Sun, '24/7': Zap, Bulk: Truck, Community: Tag, 'Back-up Power': Zap, 'FPO Certified': CheckCircle2, 'Loading Dock': Truck };

export default function HubPanel({ pendingCert }: HubPanelProps) {
  const { state, dispatch } = useApp();
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All');
  const [gpsLoading, setGpsLoading] = useState(false);
  const [selected, setSelected] = useState<ColdHub | null>(null);
  const [crates, setCrates] = useState(10);
  const [days, setDays] = useState(3);
  const [cropId, setCropId] = useState(pendingCert?.cropId ?? 'tomato');
  const [payMode, setPayMode] = useState<PayMode>('upi');
  const [booking, setBooking] = useState<Booking | null>(null);
  const [paying, setPaying] = useState(false);
  const [showGatePass, setShowGatePass] = useState(false);

  const filtered = COLD_HUBS.filter((h) => {
    if (filter === 'All') return true;
    if (filter === 'Solar Powered') return h.tags.includes('Solar');
    if (filter === '24/7') return h.tags.includes('24/7');
    if (filter === 'Bulk Dock') return h.tags.includes('Bulk') || h.tags.includes('Loading Dock');
    return true;
  }).filter((h) => !query || h.name.toLowerCase().includes(query.toLowerCase()));

  const total = selected ? Math.round(crates * days * selected.pricePerCrateDay) : 0;

  const confirmBooking = useCallback(() => {
    if (!selected) return;
    setPaying(true);
    setTimeout(() => {
      const b: Booking = {
        id: uid('bkg'),
        hubId: selected.id,
        hubName: selected.name,
        cropName: CROPS.find((c) => c.id === cropId)?.name ?? 'Tomato',
        crates, days,
        pricePerCrateDay: selected.pricePerCrateDay,
        total,
        payMode,
        bay: genBay(),
        gatePassId: genGatePass(),
        createdAt: new Date().toISOString(),
        status: 'active',
      };
      const txn: Transaction = {
        id: uid('txn'),
        type: 'cold',
        description: `Cold Storage — ${selected.name}`,
        amount: total,
        status: payMode === 'credit' ? 'credit' : 'settled',
        utr: payMode === 'credit' ? `CRED-${b.gatePassId}` : genUTR(),
        date: b.createdAt.slice(0, 10),
        hubName: selected.name,
      };
      const ledger: LedgerEntry = {
        id: uid('led'),
        type: 'cold',
        description: `Cold Storage Booking — ${selected.name}`,
        gross: total, net: total,
        status: payMode === 'credit' ? 'credit' : 'settled',
        utr: txn.utr, date: b.createdAt.slice(0, 10),
        hubName: selected.name,
        deductions: [],
      };
      dispatch({ type: 'ADD_BOOKING', booking: b, txn, ledger });
      setBooking(b);
      setPaying(false);
      setShowGatePass(true);
      setSelected(null);
    }, 1800);
  }, [selected, crates, days, cropId, payMode, total, dispatch]);

  const useMyLocation = useCallback(() => {
    if (!navigator.geolocation) { setQuery(''); return; }
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      () => { setQuery(''); setFilter('All'); setGpsLoading(false); },
      () => { setQuery(''); setGpsLoading(false); },
      { enableHighAccuracy: true, timeout: 5000 },
    );
  }, []);

  return (
    <div className="space-y-4 animate-fade-up">
      <h2 className="font-display text-lg font-bold text-forest-700">Cold Rooms & Booking (कोल्ड स्टोर)</h2>

      {pendingCert && (
        <div className="card p-3 border-2 border-forest-200 bg-forest-50 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-forest-600 text-parchment-100 flex items-center justify-center font-bold">{pendingCert.grade}</div>
          <p className="text-sm text-forest-700 font-semibold">Reserving for: {pendingCert.cropName} • {pendingCert.weightKg} kg • Batch #{pendingCert.batchId}</p>
        </div>
      )}

      {/* Search */}
      <div className="card p-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-mute" />
            <input className="input pl-10" placeholder="Village, town or PIN" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <button onClick={useMyLocation} disabled={gpsLoading} className="btn-ghost px-4 w-auto flex items-center gap-1.5">{gpsLoading ? <Loader2 size={16} className="animate-spin-slow" /> : <Navigation size={16} />} GPS</button>
        </div>
        <div className="flex gap-2 mt-3 overflow-x-auto scrollbar-none">
          {FILTER_PILLS.map((p) => (
            <button key={p} onClick={() => setFilter(p)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition ${filter === p ? 'bg-forest-600 text-parchment-100' : 'bg-parchment-200 text-mute border border-parchment-300 hover:text-forest-700'}`}>{p}</button>
          ))}
        </div>
      </div>

      {/* Hub Cards */}
      <div className="space-y-3">
        {filtered.map((h) => (
          <div key={h.id} className="card overflow-hidden">
            <div className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <Snowflake size={18} className="text-forest-500 shrink-0" />
                    <h3 className="font-display font-bold text-forest-700 truncate">{h.name}</h3>
                  </div>
                  <p className="mt-1 flex items-center gap-1.5 text-sm text-mute"><MapPin size={14} /> {h.distanceKm} km away</p>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {h.tags.map((t) => {
                      const Icon = tagIcon[t] ?? Tag;
                      return <span key={t} className="chip-forest"><Icon size={11} /> {t}</span>;
                    })}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-xl font-extrabold text-forest-700">₹{h.pricePerCrateDay}</div>
                  <span className="text-[10px] text-mute">/crate/day</span>
                  <div className="mt-1 text-xs font-bold text-profit">{h.slotsFree} slots free</div>
                </div>
              </div>
              {/* Telemetry */}
              <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-parchment-300">
                <div className="flex items-center gap-1.5 text-xs">
                  <Thermometer size={14} className="text-forest-500" />
                  <span className="text-mute">Temp:</span> <span className="font-bold text-forest-700">{h.tempC}°C</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs">
                  <Droplets size={14} className="text-forest-500" />
                  <span className="text-mute">Humidity:</span> <span className="font-bold text-forest-700">{h.humidity}%</span>
                </div>
              </div>
              <button onClick={() => setSelected(h)} className="btn-primary mt-3 flex items-center justify-center gap-2">
                <CreditCard size={17} /> Book Slot & Pay
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Active Bookings */}
      {state.bookings.filter((b) => b.status === 'active').length > 0 && (
        <div>
          <h3 className="font-display text-base font-bold text-forest-700 mb-2">Your Active Bookings</h3>
          <div className="space-y-2">
            {state.bookings.filter((b) => b.status === 'active').map((b) => (
              <div key={b.id} className="card p-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-forest-50 border border-forest-100 flex items-center justify-center"><Snowflake size={18} className="text-forest-600" /></div>
                  <div>
                    <p className="font-bold text-sm text-forest-700">{b.hubName}</p>
                    <p className="text-[11px] text-mute">{b.crates} crates • {b.days} days • Bay {b.bay} • ₹{b.total}</p>
                  </div>
                </div>
                <button onClick={() => { setBooking(b); setShowGatePass(true); }} className="flex items-center gap-1 text-xs font-bold text-forest-600 hover:underline">
                  <QrCode size={15} /> Pass
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Booking Modal */}
      <Modal open={!!selected} onClose={() => setSelected(null)} title="Book Cold Room Slot" titleHi="कोल्ड रूम स्लॉट बुक करें">
        {selected && (
          <div className="space-y-4">
            <div className="card-warm p-3">
              <h3 className="font-display font-bold text-forest-700">{selected.name}</h3>
              <p className="text-xs text-mute">{selected.distanceKm} km • {selected.tempC}°C • {selected.humidity}% humidity • {selected.slotsFree} slots free</p>
            </div>

            <div>
              <label className="label">Crop (फसल)</label>
              <select value={cropId} onChange={(e) => setCropId(e.target.value)} className="input">
                {CROPS.map((c) => <option key={c.id} value={c.id}>{c.name} — ₹{c.mandiRate}/kg</option>)}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">Crates</label>
                <input type="number" min={1} max={selected.slotsFree} value={crates} onChange={(e) => setCrates(Math.max(1, Number(e.target.value)))} className="input" />
              </div>
              <div>
                <label className="label">Days</label>
                <input type="number" min={1} max={14} value={days} onChange={(e) => setDays(Math.max(1, Number(e.target.value)))} className="input" />
              </div>
            </div>

            {crates > selected.slotsFree && (
              <p className="text-sm text-alert font-semibold">Only {selected.slotsFree} slots free. Lower the crate count.</p>
            )}

            {/* Payment Options */}
            <div className="space-y-2">
              <label className="label">Payment Option (भुगतान विकल्प)</label>
              <button onClick={() => setPayMode('upi')}
                className={`w-full p-3 rounded-xl border-2 text-left transition ${payMode === 'upi' ? 'border-forest-500 bg-forest-50' : 'border-parchment-300'}`}>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-forest-700">Option A: Pay Now via UPI</span>
                  <span className="font-extrabold text-forest-700">₹{total.toLocaleString('en-IN')}</span>
                </div>
                <p className="text-xs text-mute mt-0.5">₹0 credit, instant confirmation</p>
              </button>
              <button onClick={() => setPayMode('credit')}
                className={`w-full p-3 rounded-xl border-2 text-left transition ${payMode === 'credit' ? 'border-gold-400 bg-gold-50' : 'border-parchment-300'}`}>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-forest-700">Option B: FPO Credit (Pay Later)</span>
                  <span className="font-extrabold text-gold-600">₹0 now</span>
                </div>
                <p className="text-xs text-mute mt-0.5">Deducted from harvest sale — ₹{total.toLocaleString('en-IN')} credit</p>
              </button>
            </div>

            <div className="flex items-end justify-between pt-2 border-t border-parchment-300">
              <span className="text-sm text-mute">Total</span>
              <span className="text-3xl font-display font-black text-forest-700">₹{total.toLocaleString('en-IN')}</span>
            </div>

            <button className="btn-primary flex items-center justify-center gap-2" onClick={confirmBooking} disabled={paying || crates > selected.slotsFree}>
              {paying ? <Loader2 size={18} className="animate-spin-slow" /> : <CheckCircle2 size={18} />}
              {paying ? 'Processing…' : payMode === 'upi' ? `Pay ₹${total.toLocaleString('en-IN')} & Confirm` : 'Confirm with FPO Credit'}
            </button>
          </div>
        )}
      </Modal>

      {/* Gate Pass Modal */}
      <Modal open={showGatePass} onClose={() => setShowGatePass(false)} title="Cold Storage Gate Pass" titleHi="डिजिटल पर्ची">
        {booking && (
          <div className="space-y-4">
            <div className="card-warm p-5 border-2 border-gold-300 relative">
              <div className="absolute top-3 right-3"><Stamp text="Confirmed" /></div>
              <div className="text-center mb-4">
                <h3 className="font-display text-xl font-bold text-forest-700">{booking.hubName}</h3>
                <p className="text-xs text-gold-600 font-serif">Official Digital Parchi (Gate Pass)</p>
              </div>
              <div className="flex justify-center mb-4">
                <QRPlaceholder size={130} label={`Gate Pass #${booking.gatePassId}`} />
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                {[
                  ['Gate Pass ID', `#${booking.gatePassId}`],
                  ['Bay / Slot', booking.bay],
                  ['Crop', booking.cropName],
                  ['Crates', String(booking.crates)],
                  ['Duration', `${booking.days} days`],
                  ['Payment', booking.payMode === 'upi' ? 'UPI Paid' : 'FPO Credit'],
                  ['Total', `₹${booking.total.toLocaleString('en-IN')}`],
                  ['Date', new Date(booking.createdAt).toLocaleDateString('en-IN')],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between py-1.5 border-b border-parchment-300">
                    <span className="text-mute text-xs font-semibold uppercase">{k}</span>
                    <span className="font-bold text-forest-700">{v}</span>
                  </div>
                ))}
              </div>
            </div>
            <p className="text-xs text-center text-mute">Show this QR at the cold room gate for entry. Keep this parchi for your records.</p>
            <button className="btn-primary" onClick={() => setShowGatePass(false)}>Done</button>
          </div>
        )}
      </Modal>
    </div>
  );
}
