import { useCallback, useEffect, useRef, useState } from 'react';
import { Camera, CameraOff, RefreshCw, Sparkles, Thermometer, AlertTriangle, Snowflake, ShoppingCart, ScanLine, Award } from 'lucide-react';
import { useApp } from '@/lib/context';
import { CROPS, type Certificate, type Grade } from '@/lib/types';
import { analyzeCrate, genBatchId } from '@/lib/scan';
import { uid } from '@/lib/store';
import { Stamp } from './ui';

interface ScanPanelProps { onFindColdRoom: (cert: Certificate) => void; onListForSale: (cert: Certificate) => void; }

export default function ScanPanel({ onFindColdRoom, onListForSale }: ScanPanelProps) {
  const { state, dispatch } = useApp();
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [cameraOn, setCameraOn] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [cropId, setCropId] = useState('tomato');
  const [weightKg, setWeightKg] = useState(500);
  const [result, setResult] = useState<Certificate | null>(null);

  const crop = CROPS.find((c) => c.id === cropId)!;

  const stopCamera = useCallback(() => {
    if (streamRef.current) { streamRef.current.getTracks().forEach((t) => t.stop()); streamRef.current = null; }
    if (videoRef.current) videoRef.current.srcObject = null;
    setCameraOn(false);
  }, []);

  const startCamera = useCallback(async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
      streamRef.current = stream;
      if (videoRef.current) { videoRef.current.srcObject = stream; await videoRef.current.play(); }
      setCameraOn(true);
    } catch {
      setCameraError('Camera unavailable — use Simulate Scan instead.');
    }
  }, []);

  useEffect(() => () => stopCamera(), [stopCamera]);

  const doScan = useCallback(async () => {
    setScanning(true); setResult(null);
    await new Promise((r) => setTimeout(r, 2500));
    const ripeness = 35 + Math.floor(Math.random() * 30);
    const bruising = Math.floor(Math.random() * 35);
    const res = analyzeCrate({ cropId, ripeness, bruising, weightKg });
    const cert: Certificate = {
      batchId: genBatchId(), cropId, cropName: crop.name,
      grade: res.grade, confidence: res.confidence, uniformity: res.uniformity,
      spoilageRisk: res.spoilageRisk,
      shelfLifeNoCool: res.shelfLifeHours, shelfLifeCool: res.coldLifeHours,
      weightKg, mandiRate: crop.mandiRate, createdAt: new Date().toISOString(),
      photoUrl: null,
    };
    setResult(cert); setScanning(false);
    dispatch({ type: 'ADD_CERT', cert });
  }, [cropId, weightKg, crop, dispatch]);

  const gradeStyle: Record<Grade, { text: string; bg: string; label: string; desc: string }> = {
    A: { text: 'text-profit', bg: 'bg-green-50 border-green-300', label: 'Grade A', desc: 'Export / Retail Quality' },
    B: { text: 'text-warn', bg: 'bg-amber-50 border-amber-300', label: 'Grade B', desc: 'Local Market Quality' },
    C: { text: 'text-alert', bg: 'bg-red-50 border-red-300', label: 'Grade C', desc: 'Process / Rescue Quality' },
  };

  return (
    <div className="space-y-4 animate-fade-up">
      {/* Crop Selector */}
      <div>
        <h2 className="font-display text-lg font-bold text-forest-700 mb-2">Select Crop (फसल चुनें)</h2>
        <div className="grid grid-cols-3 gap-2.5">
          {CROPS.map((c) => (
            <button key={c.id} onClick={() => setCropId(c.id)}
              className={`card p-3 flex flex-col items-center gap-1 transition-all hover:shadow-pop ${cropId === c.id ? 'ring-2 ring-forest-500 border-forest-500' : ''}`}>
              <span className="text-2xl">{c.emoji}</span>
              <span className="text-[13px] font-bold text-forest-700 leading-tight text-center">{c.name}</span>
              <span className="text-[10px] text-gold-600 font-semibold">₹{c.mandiRate}/kg</span>
              <span className="text-[9px] text-mute">{c.idealTemp}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Weight Input */}
      <div className="card p-4">
        <label className="label" htmlFor="weight">Crate Weight (kg)</label>
        <input id="weight" type="number" min={1} value={weightKg} onChange={(e) => setWeightKg(Math.max(1, Number(e.target.value)))} className="input" />
      </div>

      {/* Camera / Viewfinder */}
      <div className="card p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="font-display text-base font-bold text-forest-700">Crate Scanner</span>
          {cameraOn ? (
            <button onClick={stopCamera} className="flex items-center gap-1.5 text-sm font-bold text-alert hover:underline">
              <CameraOff size={16} /> Stop
            </button>
          ) : (
            <button onClick={startCamera} className="flex items-center gap-1.5 text-sm font-bold text-forest-600 hover:underline">
              <Camera size={16} /> Start Camera
            </button>
          )}
        </div>

        {cameraError && (
          <div className="flex items-start gap-2 p-3 rounded-lg bg-red-50 text-alert text-sm mb-3 border border-red-200">
            <AlertTriangle size={18} className="shrink-0 mt-0.5" /><span>{cameraError}</span>
          </div>
        )}

        <div className="relative rounded-xl overflow-hidden bg-forest-900 aspect-[4/3]">
          <video ref={videoRef} playsInline muted className={`w-full h-full object-cover ${cameraOn ? 'block' : 'hidden'}`} />
          {!cameraOn && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-parchment-100 gap-2 bg-grid">
              <ScanLine size={44} className="opacity-50" />
              <p className="text-sm opacity-70 text-center px-4">Start camera or simulate a scan to grade your crate</p>
            </div>
          )}
          {/* Viewfinder frame */}
          <div className="absolute inset-4 border-2 border-gold-300/70 rounded-lg pointer-events-none" />
          <div className="absolute top-4 left-4 w-6 h-6 border-t-2 border-l-2 border-gold-400 rounded-tl-lg pointer-events-none" />
          <div className="absolute top-4 right-4 w-6 h-6 border-t-2 border-r-2 border-gold-400 rounded-tr-lg pointer-events-none" />
          <div className="absolute bottom-4 left-4 w-6 h-6 border-b-2 border-l-2 border-gold-400 rounded-bl-lg pointer-events-none" />
          <div className="absolute bottom-4 right-4 w-6 h-6 border-b-2 border-r-2 border-gold-400 rounded-br-lg pointer-events-none" />
          {/* Scanning laser */}
          {scanning && (
            <div className="absolute inset-4 rounded-lg overflow-hidden pointer-events-none">
              <div className="absolute left-0 right-0 h-1 bg-gold-400/80 shadow-[0_0_12px_4px_rgba(176,137,56,0.5)] animate-laser" />
              <div className="absolute inset-0 bg-gold-400/5" />
            </div>
          )}
          {scanning && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-full bg-forest-800/80 text-gold-300 text-xs font-bold flex items-center gap-1.5">
              <RefreshCw size={13} className="animate-spin-slow" /> AI Grading in progress…
            </div>
          )}
        </div>

        <button className="btn-primary mt-4 flex items-center justify-center gap-2" onClick={doScan} disabled={scanning}>
          {scanning ? <RefreshCw size={18} className="animate-spin-slow" /> : <Sparkles size={18} />}
          {scanning ? 'Scanning…' : cameraOn ? 'Capture & Scan' : 'Simulate Crate Scan'}
        </button>
      </div>

      {/* Certificate */}
      {result && (
        <div className={`card p-5 border-2 ${gradeStyle[result.grade].bg} animate-stamp`}>
          {/* Certificate header */}
          <div className="flex items-start justify-between border-b border-parchment-300 pb-3 mb-3">
            <div>
              <div className="flex items-center gap-2">
                <Award size={20} className="text-gold-600" />
                <h3 className="font-display text-lg font-bold text-forest-700">AI Crate Quality Certificate</h3>
              </div>
              <p className="text-[11px] text-mute mt-0.5">Batch ID: <span className="font-bold text-forest-600">#{result.batchId}</span> • {new Date(result.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
            </div>
            <Stamp text="Official" />
          </div>

          {/* Grade display */}
          <div className="flex items-end justify-between mb-4">
            <div>
              <div className={`text-5xl font-display font-black ${gradeStyle[result.grade].text}`}>{result.grade}</div>
              <span className="text-xs font-bold text-mute uppercase tracking-wide">{gradeStyle[result.grade].label} — {gradeStyle[result.grade].desc}</span>
            </div>
            <div className="text-right">
              <div className="text-2xl font-extrabold text-forest-700">{result.confidence}%</div>
              <span className="text-[11px] text-mute">Confidence</span>
            </div>
          </div>

          {/* Metrics grid */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            {[
              { label: 'Uniformity', value: `${result.uniformity}%` },
              { label: 'Spoilage Risk', value: result.spoilageRisk },
              { label: 'Shelf Life (No Cooling)', value: `${result.shelfLifeNoCool} days` },
              { label: 'Shelf Life (Cold Room)', value: `${result.shelfLifeCool} days` },
            ].map((m) => (
              <div key={m.label} className="p-2.5 rounded-lg bg-parchment-50 border border-parchment-300">
                <div className="text-[11px] text-mute font-semibold uppercase tracking-wide">{m.label}</div>
                <div className="text-base font-bold text-forest-700 mt-0.5">{m.value}</div>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-2 p-3 rounded-lg bg-forest-50 border border-forest-100 mb-4">
            <Thermometer size={16} className="text-forest-600 shrink-0" />
            <p className="text-xs text-forest-700">
              Cold room extends shelf life from <b>{result.shelfLifeNoCool} days</b> to <b>{result.shelfLifeCool} days</b> — {Math.round(result.shelfLifeCool / Math.max(1, result.shelfLifeNoCool))}× longer.
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-2.5">
            {result.grade !== 'C' && (
              <button className="btn-primary flex-1 flex items-center justify-center gap-2" onClick={() => onFindColdRoom(result)}>
                <Snowflake size={18} /> Reserve Cold Room
              </button>
            )}
            <button className="btn-gold flex-1 flex items-center justify-center gap-2" onClick={() => onListForSale(result)}>
              <ShoppingCart size={18} /> List for Escrow Sale
            </button>
          </div>
        </div>
      )}

      {/* Recent Scans */}
      {state.certificates.length > 0 && !result && (
        <div>
          <h3 className="font-display text-base font-bold text-forest-700 mb-2">Recent Scans (हाल के स्कैन)</h3>
          <div className="space-y-2">
            {state.certificates.slice(0, 3).map((c) => (
              <div key={c.batchId} className="card p-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center font-display font-black text-xl ${gradeStyle[c.grade].text} ${gradeStyle[c.grade].bg} border-2`}>{c.grade}</div>
                  <div>
                    <p className="font-bold text-sm text-forest-700">{c.cropName} • {c.weightKg} kg</p>
                    <p className="text-[11px] text-mute">#{c.batchId} • {c.confidence}% confidence</p>
                  </div>
                </div>
                <button onClick={() => setResult(c)} className="text-xs font-bold text-forest-600 hover:underline">View</button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
