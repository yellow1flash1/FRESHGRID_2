import { Sprout, TrendingUp, TrendingDown, Minus, LogOut, Monitor, Smartphone } from 'lucide-react';
import { useApp } from '@/lib/context';
import { MANDI_TICKER } from '@/lib/types';
import { VerifiedSeal } from './ui';

export default function Header() {
  const { state, dispatch } = useApp();
  const farmer = state.farmer!;

  const tickerItems = [...MANDI_TICKER, ...MANDI_TICKER];

  return (
    <header className="sticky top-0 z-20 bg-parchment-100/90 backdrop-blur-md border-b border-parchment-300">
      {/* Mandi Ticker */}
      <div className="bg-forest-700 text-parchment-100 overflow-hidden">
        <div className="flex items-center">
          <span className="flex items-center gap-1 px-3 py-1.5 bg-forest-800 text-gold-300 text-[10px] font-bold uppercase tracking-wider whitespace-nowrap shrink-0">
            <TrendingUp size={12} /> Mandi Live
          </span>
          <div className="relative flex-1 overflow-hidden">
            <div className="flex gap-6 py-1.5 animate-marquee whitespace-nowrap">
              {tickerItems.map((t, i) => (
                <span key={i} className="text-xs font-semibold flex items-center gap-1.5">
                  <span className="text-gold-300">{t.crop}:</span>
                  <span>₹{t.rate}/kg</span>
                  {t.trend === 'up' && <TrendingUp size={11} className="text-green-400" />}
                  {t.trend === 'down' && <TrendingDown size={11} className="text-red-400" />}
                  {t.trend === 'flat' && <Minus size={11} className="text-gold-300" />}
                  <span className={t.trend === 'up' ? 'text-green-400' : t.trend === 'down' ? 'text-red-400' : 'text-gold-300'}>
                    {t.change > 0 ? `+${t.change}%` : t.change < 0 ? `${t.change}%` : '0%'}
                  </span>
                  <span className="text-forest-300">|</span>
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="px-4 py-3">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-11 h-11 rounded-xl bg-forest-600 text-gold-300 flex items-center justify-center shadow-card shrink-0">
              <Sprout size={24} />
            </div>
            <div className="min-w-0">
              <h1 className="font-display text-xl font-bold text-forest-700 leading-none">FreshGrid</h1>
              <p className="text-[11px] text-gold-600 font-serif tracking-wide">Scan · Store · Sell</p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* View Mode Toggle */}
            <button
              onClick={() => dispatch({ type: 'SET_VIEW', mode: state.viewMode === 'mobile' ? 'desktop' : 'mobile' })}
              className="p-2 rounded-lg bg-parchment-200 border border-parchment-300 text-mute hover:text-forest-700 transition"
              aria-label="Toggle view mode"
              title={state.viewMode === 'mobile' ? 'Switch to Desktop Mode' : 'Switch to Mobile Mode'}
            >
              {state.viewMode === 'mobile' ? <Monitor size={16} /> : <Smartphone size={16} />}
            </button>

            {/* Font Scale Toggle */}
            <div className="flex items-center bg-parchment-200 border border-parchment-300 rounded-lg overflow-hidden">
              {(['sm', 'md', 'lg'] as const).map((s) => (
                <button key={s} onClick={() => dispatch({ type: 'SET_FONT', scale: s })}
                  className={`px-2 py-1.5 text-xs font-bold transition ${state.fontScale === s ? 'bg-forest-600 text-parchment-100' : 'text-mute hover:text-forest-700'}`}>
                  {s === 'sm' ? 'A-' : s === 'md' ? 'A' : 'A+'}
                </button>
              ))}
            </div>

            {/* Language Toggle */}
            <div className="flex items-center bg-parchment-200 border border-parchment-300 rounded-lg overflow-hidden">
              <button onClick={() => dispatch({ type: 'SET_LANG', lang: 'en' })}
                className={`px-2.5 py-1.5 text-xs font-bold transition ${state.lang === 'en' ? 'bg-forest-600 text-parchment-100' : 'text-mute hover:text-forest-700'}`}>EN</button>
              <button onClick={() => dispatch({ type: 'SET_LANG', lang: 'hi' })}
                className={`px-2.5 py-1.5 text-xs font-bold transition ${state.lang === 'hi' ? 'bg-forest-600 text-parchment-100' : 'text-mute hover:text-forest-700'}`}>हिं</button>
            </div>
          </div>
        </div>

        {/* Farmer Profile Pill */}
        <div className="mt-2.5 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-full bg-gold-300 border border-gold-400 flex items-center justify-center text-forest-800 font-bold text-sm shrink-0">
              {farmer.name.charAt(0)}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-bold text-forest-700 truncate">{farmer.name} <VerifiedSeal label="Verified" /></p>
              <p className="text-[11px] text-mute truncate">FPO ID: #{farmer.fpoId} • {farmer.village}, {farmer.district}</p>
            </div>
          </div>
          <button onClick={() => dispatch({ type: 'LOGOUT' })} className="flex items-center gap-1 text-xs font-bold text-alert hover:underline shrink-0">
            <LogOut size={14} /> Logout
          </button>
        </div>
      </div>
    </header>
  );
}
