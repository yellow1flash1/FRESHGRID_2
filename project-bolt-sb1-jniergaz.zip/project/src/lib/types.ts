export type Grade = 'A' | 'B' | 'C';
export type Lang = 'en' | 'hi';
export type FontScale = 'sm' | 'md' | 'lg';
export type ViewMode = 'mobile' | 'desktop';
export type Tab = 'scan' | 'hub' | 'income' | 'payments' | 'chat';
export type PayMode = 'upi' | 'credit';
export type TxnType = 'sale' | 'cold' | 'transport' | 'payout';
export type TxnStatus = 'settled' | 'escrow' | 'pending' | 'credit';

export interface Crop {
  id: string;
  name: string;
  nameHi: string;
  emoji: string;
  mandiRate: number;
  baseHours: number;
  idealTemp: string;
  color: string;
}

export interface FarmerProfile {
  id: string;
  name: string;
  mobile: string;
  state: string;
  district: string;
  village: string;
  fpoId: string;
  kisanId: string;
  idType: 'Aadhaar' | 'KCC' | 'PM-Kisan';
  idVerified: boolean;
  upiId: string;
  upiName: string;
  bankName: string;
  bankAcc: string;
  upiVerified: boolean;
  joinedAt: string;
}

export interface Certificate {
  batchId: string;
  cropId: string;
  cropName: string;
  grade: Grade;
  confidence: number;
  uniformity: number;
  spoilageRisk: string;
  shelfLifeNoCool: number;
  shelfLifeCool: number;
  weightKg: number;
  mandiRate: number;
  createdAt: string;
  photoUrl: string | null;
}

export interface ColdHub {
  id: string;
  name: string;
  nameHi: string;
  distanceKm: number;
  pricePerCrateDay: number;
  slotsFree: number;
  slotsTotal: number;
  tempC: number;
  humidity: number;
  tags: string[];
  badges: string[];
}

export interface Booking {
  id: string;
  hubId: string;
  hubName: string;
  cropName: string;
  crates: number;
  days: number;
  pricePerCrateDay: number;
  total: number;
  payMode: PayMode;
  bay: string;
  gatePassId: string;
  createdAt: string;
  status: 'active' | 'completed';
}

export interface Transaction {
  id: string;
  type: TxnType;
  description: string;
  amount: number;
  status: TxnStatus;
  utr: string;
  date: string;
  cropName?: string;
  weightKg?: number;
  grade?: Grade;
  hubName?: string;
  deductions?: { label: string; amount: number }[];
}

export interface LedgerEntry {
  id: string;
  type: TxnType;
  description: string;
  gross: number;
  deductions: { label: string; amount: number }[];
  net: number;
  status: TxnStatus;
  utr: string;
  date: string;
  cropName?: string;
  weightKg?: number;
  grade?: Grade;
  hubName?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

export interface AppState {
  farmer: FarmerProfile | null;
  certificates: Certificate[];
  bookings: Booking[];
  transactions: Transaction[];
  ledger: LedgerEntry[];
  wallet: {
    totalEarned: number;
    inEscrow: number;
    coldCredit: number;
  };
  chat: ChatMessage[];
  lang: Lang;
  fontScale: FontScale;
  viewMode: ViewMode;
}

export const CROPS: Crop[] = [
  { id: 'tomato', name: 'Tomato', nameHi: 'टमाटर', emoji: '🍅', mandiRate: 32, baseHours: 48, idealTemp: '12–15°C', color: '#C4402C' },
  { id: 'beans', name: 'Green Beans', nameHi: 'हरी फली', emoji: '🫛', mandiRate: 45, baseHours: 72, idealTemp: '7–10°C', color: '#2D6A4F' },
  { id: 'mango', name: 'Mango', nameHi: 'आम', emoji: '🥭', mandiRate: 65, baseHours: 96, idealTemp: '10–13°C', color: '#B08938' },
  { id: 'papaya', name: 'Papaya', nameHi: 'पपीता', emoji: '🟧', mandiRate: 28, baseHours: 60, idealTemp: '8–12°C', color: '#D4A373' },
  { id: 'banana', name: 'Banana', nameHi: 'केला', emoji: '🍌', mandiRate: 35, baseHours: 120, idealTemp: '13–14°C', color: '#EAD0A0' },
  { id: 'spinach', name: 'Spinach', nameHi: 'पालक', emoji: '🥬', mandiRate: 24, baseHours: 36, idealTemp: '1–2°C', color: '#3D7A4E' },
];

export const COLD_HUBS: ColdHub[] = [
  {
    id: 'sunrise',
    name: 'Sunrise Solar Cold Hub',
    nameHi: 'सनराइज़ सोलर कोल्ड हब',
    distanceKm: 2.7,
    pricePerCrateDay: 18,
    slotsFree: 24,
    slotsTotal: 100,
    tempC: 4.2,
    humidity: 88,
    tags: ['Solar', '24/7', 'FPO Certified'],
    badges: ['Solar Powered', '24×7 Access', 'FPO Certified'],
  },
  {
    id: 'gramseva',
    name: 'Gram Seva Cold Room',
    nameHi: 'ग्राम सेवा कोल्ड रूम',
    distanceKm: 5.5,
    pricePerCrateDay: 14,
    slotsFree: 60,
    slotsTotal: 150,
    tempC: 6.0,
    humidity: 85,
    tags: ['Community', 'Back-up Power'],
    badges: ['Community Run', 'Back-up Power'],
  },
  {
    id: 'kisanfpo',
    name: 'Kisan FPO Chiller',
    nameHi: 'किसान FPO चिलर',
    distanceKm: 8.1,
    pricePerCrateDay: 11,
    slotsFree: 90,
    slotsTotal: 200,
    tempC: 5.0,
    humidity: 90,
    tags: ['Bulk', 'Loading Dock'],
    badges: ['Bulk Capacity', 'Loading Dock'],
  },
];

export const MANDI_TICKER = [
  { crop: 'Tomato', rate: 32, change: 4, trend: 'up' },
  { crop: 'Mango', rate: 65, change: 2, trend: 'up' },
  { crop: 'Spinach', rate: 22, change: 1, trend: 'down' },
  { crop: 'Green Beans', rate: 45, change: 3, trend: 'up' },
  { crop: 'Banana', rate: 35, change: 0, trend: 'flat' },
  { crop: 'Papaya', rate: 28, change: 1, trend: 'down' },
];

export const STATES = ['Haryana', 'Punjab', 'Uttar Pradesh', 'Rajasthan', 'Madhya Pradesh', 'Maharashtra', 'Gujarat', 'Karnataka'];
export const DISTRICTS: Record<string, string[]> = {
  Haryana: ['Sonipat', 'Karnal', 'Rohtak', 'Hisar'],
  Punjab: ['Ludhiana', 'Amritsar', 'Patiala'],
  'Uttar Pradesh': ['Meerut', 'Agra', 'Aligarh'],
  Rajasthan: ['Jaipur', 'Kota', 'Bikaner'],
  'Madhya Pradesh': ['Bhopal', 'Indore', 'Ujjain'],
  Maharashtra: ['Pune', 'Nashik', 'Nagpur'],
  Gujarat: ['Ahmedabad', 'Surat', 'Vadodara'],
  Karnataka: ['Bengaluru', 'Mysuru', 'Hubli'],
};
