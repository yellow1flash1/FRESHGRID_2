import type { Grade, Crop } from './types';
import { CROPS } from './types';

export interface ScanInput { cropId: string; ripeness: number; bruising: number; weightKg: number; }
export interface ScanResult {
  grade: Grade; shelfLifeHours: number; coldLifeHours: number;
  confidence: number; uniformity: number; spoilageRisk: string; score: number;
}

export function getCrop(id: string): Crop {
  return CROPS.find((c) => c.id === id) ?? CROPS[0];
}

export function analyzeCrate(input: ScanInput): ScanResult {
  const crop = getCrop(input.cropId);
  const base = crop.baseHours;
  const { ripeness, bruising } = input;
  const score = Math.max(0, 100 - bruising * 0.85 - Math.abs(ripeness - 45) * 0.45);
  const shelfLifeHours = Math.max(6, Math.round(base * (1 - bruising / 120) * (1 - Math.max(0, ripeness - 50) / 90)));
  const coldLifeHours = Math.round(shelfLifeHours * 6);
  const confidence = Math.min(99, Math.round(88 + (100 - bruising) * 0.1 + Math.random() * 4));
  const uniformity = Math.min(98, Math.round(82 + (100 - bruising) * 0.14 + Math.random() * 3));
  const spoilageRisk = bruising < 20 ? 'Low (<3%)' : bruising < 45 ? 'Moderate (3–8%)' : 'High (>8%)';
  const grade: Grade = score >= 75 && shelfLifeHours >= 36 ? 'A' : shelfLifeHours < 36 || score < 45 ? 'C' : 'B';
  return { grade, shelfLifeHours, coldLifeHours, confidence, uniformity, spoilageRisk, score };
}

export function genBatchId(): string {
  const n = Math.floor(1000 + Math.random() * 9000);
  return `FG-CR-${n}`;
}

export function genBay(): string {
  const row = String.fromCharCode(65 + Math.floor(Math.random() * 4));
  const slot = 1 + Math.floor(Math.random() * 30);
  return `${row}-${slot}`;
}

export function genGatePass(): string {
  return `GP-${Math.floor(1000 + Math.random() * 9000)}`;
}
