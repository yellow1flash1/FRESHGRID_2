import type { AppState, FarmerProfile, Certificate, Booking, Transaction, LedgerEntry, ChatMessage } from './types';

const STORAGE_KEY = 'freshgrid_app_state_v1';

export const DEMO_FARMER: FarmerProfile = {
  id: 'farmer-001',
  name: 'Kishan Lal',
  mobile: '9876543210',
  state: 'Haryana',
  district: 'Sonipat',
  village: 'Rai',
  fpoId: 'HR-SNP-4092',
  kisanId: 'PMKMY-29104872',
  idType: 'PM-Kisan',
  idVerified: true,
  upiId: 'kishanlal@sbi',
  upiName: 'KISHAN LAL',
  bankName: 'State Bank of India',
  bankAcc: '4821',
  upiVerified: true,
  joinedAt: '2025-09-01',
};

const DEMO_LEDGER: LedgerEntry[] = [
  {
    id: 'led-001', type: 'sale', description: 'Tomato Sale — Reliance Fresh Pool',
    gross: 32000, net: 28352, status: 'settled', utr: '629104882910',
    date: '2026-10-10', cropName: 'Tomato', weightKg: 1000, grade: 'A',
    deductions: [
      { label: 'Cold Storage Fee', amount: 1080 },
      { label: 'Pooled FPO Transport', amount: 1820 },
      { label: 'Platform Fee (3%)', amount: 748 },
    ],
  },
  {
    id: 'led-002', type: 'cold', description: 'Cold Storage Booking — Sunrise Solar Hub',
    gross: 540, net: 540, status: 'credit', utr: 'COLD-CR-7721',
    date: '2026-10-08', hubName: 'Sunrise Solar Cold Hub',
    deductions: [],
  },
  {
    id: 'led-003', type: 'sale', description: 'Mango Sale — Mother Dairy FPO Pool',
    gross: 19500, net: 17248, status: 'settled', utr: '629104771204',
    date: '2026-09-28', cropName: 'Mango', weightKg: 300, grade: 'A',
    deductions: [
      { label: 'Cold Storage Fee', amount: 640 },
      { label: 'Pooled FPO Transport', amount: 980 },
      { label: 'Platform Fee (3%)', amount: 632 },
    ],
  },
];

const DEMO_TXNS: Transaction[] = [
  {
    id: 'txn-001', type: 'sale', description: 'Tomato Sale — Reliance Fresh Pool',
    amount: 28352, status: 'settled', utr: '629104882910', date: '2026-10-10',
    cropName: 'Tomato', weightKg: 1000, grade: 'A',
  },
  {
    id: 'txn-002', type: 'sale', description: 'Buyer Order Pending Delivery — Tomato 1000 kg',
    amount: 20388, status: 'escrow', utr: 'ESC-7720', date: '2026-10-12',
    cropName: 'Tomato', weightKg: 1000, grade: 'A',
  },
  {
    id: 'txn-003', type: 'cold', description: 'Cold Storage — Sunrise Solar Hub',
    amount: 540, status: 'credit', utr: 'COLD-CR-7721', date: '2026-10-08',
    hubName: 'Sunrise Solar Cold Hub',
  },
  {
    id: 'txn-004', type: 'sale', description: 'Mango Sale — Mother Dairy Pool',
    amount: 17248, status: 'settled', utr: '629104771204', date: '2026-09-28',
    cropName: 'Mango', weightKg: 300, grade: 'A',
  },
  {
    id: 'txn-005', type: 'transport', description: 'Pooled Transport Fee — Tomato Batch',
    amount: 1820, status: 'settled', utr: 'TRN-8821', date: '2026-10-10',
  },
];

const DEMO_BOOKINGS: Booking[] = [
  {
    id: 'bkg-001', hubId: 'sunrise', hubName: 'Sunrise Solar Cold Hub',
    cropName: 'Tomato', crates: 10, days: 3, pricePerCrateDay: 18, total: 540,
    payMode: 'credit', bay: 'B-14', gatePassId: 'GP-7721',
    createdAt: '2026-10-08', status: 'active',
  },
];

const DEMO_CERTS: Certificate[] = [
  {
    batchId: 'FG-CR-8821', cropId: 'tomato', cropName: 'Tomato',
    grade: 'A', confidence: 94, uniformity: 91, spoilageRisk: 'Low (<3%)',
    shelfLifeNoCool: 3, shelfLifeCool: 18, weightKg: 1000, mandiRate: 32,
    createdAt: '2026-10-12', photoUrl: null,
  },
];

const DEMO_CHAT: ChatMessage[] = [
  {
    id: 'msg-0', role: 'assistant',
    content: "Namaste, Kishan ji! I'm your FreshGrid Kisan Assistant. I can help you scan crates, find cold rooms, understand your escrow payments, or calculate your income. Tap a suggestion below or type your question.",
    createdAt: new Date().toISOString(),
  },
];

export const INITIAL_STATE: AppState = {
  farmer: null,
  certificates: DEMO_CERTS,
  bookings: DEMO_BOOKINGS,
  transactions: DEMO_TXNS,
  ledger: DEMO_LEDGER,
  wallet: { totalEarned: 64250, inEscrow: 20388, coldCredit: 540 },
  chat: DEMO_CHAT,
  lang: 'en',
  fontScale: 'md',
  viewMode: 'mobile',
};

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<AppState>;
      return { ...INITIAL_STATE, ...parsed, chat: parsed.chat?.length ? parsed.chat : DEMO_CHAT };
    }
  } catch {}
  return { ...INITIAL_STATE };
}

export function saveState(state: AppState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {}
}

export function clearState() {
  try { localStorage.removeItem(STORAGE_KEY); } catch {}
}

export function uid(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`.toUpperCase();
}

export function genUTR(): string {
  return Array.from({ length: 12 }, () => Math.floor(Math.random() * 10)).join('');
}
