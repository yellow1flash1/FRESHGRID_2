import type { Lang } from './types';

type Dict = Record<string, { en: string; hi: string }>;

const DICT: Dict = {
  scanCrate: { en: 'Scan Crate', hi: 'क्रेट स्कैन' },
  coldRooms: { en: 'Cold Rooms', hi: 'कोल्ड स्टोर' },
  payments: { en: 'Payments & Khata', hi: 'भुगतान और खाता' },
  income: { en: 'My Income', hi: 'मेरी आय' },
  assistant: { en: 'Kisan Assistant', hi: 'किसान सहायक' },
  login: { en: 'Log In', hi: 'लॉग इन' },
  register: { en: 'Register', hi: 'पंजीकरण' },
  demoLogin: { en: 'Demo Quick Login', hi: 'डेमो लॉग इन' },
  logout: { en: 'Logout', hi: 'लॉगआउट' },
  selectCrop: { en: 'Select Crop', hi: 'फसल चुनें' },
  startScan: { en: 'Start Scan', hi: 'स्कैन शुरू करें' },
  simulateScan: { en: 'Simulate Scan', hi: 'स्कैन सिम्युलेट' },
  reserveColdRoom: { en: 'Reserve Cold Room', hi: 'कोल्ड रूम बुक करें' },
  listForSale: { en: 'List for Buyer Escrow Sale', hi: 'बिक्री के लिए लिस्ट करें' },
  bookSlot: { en: 'Book Slot & Pay', hi: 'स्लॉट बुक करें' },
  payNow: { en: 'Pay Now via UPI', hi: 'अभी भुगतान करें' },
  payLater: { en: 'Pay Later from Sale', hi: 'बाद में भुगतान' },
  totalEarned: { en: 'Total Earned This Season', hi: 'इस सीज़न की कुल आय' },
  inEscrow: { en: 'In Buyer Escrow', hi: 'एस्क्रो में लंबित' },
  coldCredit: { en: 'Cold Storage Credit', hi: 'कोल्ड स्टोर क्रेडिट' },
  releaseEscrow: { en: 'Show Delivery QR to Buyer', hi: 'बायर को QR दिखाएं' },
  simulateQR: { en: 'Simulate Buyer QR Scan & Release', hi: 'QR स्कैन सिम्युलेट करें' },
  viewReceipt: { en: 'View Parchi / Receipt', hi: 'रसीद देखें' },
  withoutFG: { en: 'Without FreshGrid', hi: 'FreshGrid के बिना' },
  withFG: { en: 'With FreshGrid', hi: 'FreshGrid के साथ' },
  lockDeal: { en: 'Lock This Deal & Generate Sale Lot', hi: 'डील लॉक करें' },
  voiceAsk: { en: 'Ask by Voice', hi: 'बोलकर पूछें' },
  verified: { en: 'Verified', hi: 'सत्यापित' },
  secureUPI: { en: '100% Secure UPI Payout', hi: 'सुरक्षित UPI भुगतान' },
  fpoPartner: { en: 'Registered FPO Partner', hi: 'FPO पार्टनर' },
  enamLinked: { en: 'e-NAM & Govt ID Linked', hi: 'e-NAM लिंक्ड' },
  useLocation: { en: 'Use My Location', hi: 'मेरा स्थान उपयोग करें' },
  searchVillage: { en: 'Search village, town or PIN', hi: 'गाँव या कस्बा खोजें' },
};

export function t(key: keyof typeof DICT, lang: Lang): string {
  return DICT[key]?.[lang] ?? key;
}

export function bi(key: keyof typeof DICT, lang: Lang): string {
  const e = DICT[key];
  if (!e) return key;
  return lang === 'hi' ? `${e.en} (${e.hi})` : `${e.en} (${e.hi})`;
}
