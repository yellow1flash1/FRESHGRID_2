import { createContext, useContext, useEffect, useReducer, type ReactNode, type Dispatch } from 'react';
import type { AppState } from './types';
import { loadState, saveState, INITIAL_STATE } from './store';

type Action =
  | { type: 'SET_STATE'; state: AppState }
  | { type: 'LOGIN'; farmer: AppState['farmer'] }
  | { type: 'LOGOUT' }
  | { type: 'ADD_CERT'; cert: AppState['certificates'][number] }
  | { type: 'ADD_BOOKING'; booking: AppState['bookings'][number]; txn: AppState['transactions'][number]; ledger: AppState['ledger'][number] }
  | { type: 'RELEASE_ESCROW'; txnId: string; ledger: AppState['ledger'][number] }
  | { type: 'ADD_TXN'; txn: AppState['transactions'][number]; ledger: AppState['ledger'][number] }
  | { type: 'ADD_CHAT'; msg: AppState['chat'][number] }
  | { type: 'SET_LANG'; lang: AppState['lang'] }
  | { type: 'SET_FONT'; scale: AppState['fontScale'] }
  | { type: 'SET_VIEW'; mode: AppState['viewMode'] }
  | { type: 'LOCK_DEAL'; txn: AppState['transactions'][number] }
  | { type: 'CLEAR_DUES'; amount: number; utr: string }
  | { type: 'RESET' };

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_STATE': return action.state;
    case 'LOGIN': return { ...state, farmer: action.farmer };
    case 'LOGOUT': return { ...INITIAL_STATE, lang: state.lang, fontScale: state.fontScale, viewMode: state.viewMode };
    case 'ADD_CERT': return { ...state, certificates: [action.cert, ...state.certificates] };
    case 'ADD_BOOKING': {
      const wallet = { ...state.wallet };
      if (action.booking.payMode === 'credit') wallet.coldCredit += action.booking.total;
      return {
        ...state,
        bookings: [action.booking, ...state.bookings],
        transactions: [action.txn, ...state.transactions],
        ledger: [action.ledger, ...state.ledger],
        wallet,
      };
    }
    case 'RELEASE_ESCROW': {
      const escrowTxn = state.transactions.find((t) => t.id === action.txnId);
      if (!escrowTxn) return state;
      const amount = escrowTxn.amount;
      return {
        ...state,
        transactions: state.transactions.map((t) => t.id === action.txnId ? { ...t, status: 'settled' } : t),
        ledger: [action.ledger, ...state.ledger],
        wallet: { ...state.wallet, inEscrow: Math.max(0, state.wallet.inEscrow - amount), totalEarned: state.wallet.totalEarned + amount },
      };
    }
    case 'ADD_TXN': {
      return { ...state, transactions: [action.txn, ...state.transactions], ledger: [action.ledger, ...state.ledger] };
    }
    case 'ADD_CHAT': return { ...state, chat: [...state.chat, action.msg] };
    case 'SET_LANG': return { ...state, lang: action.lang };
    case 'SET_FONT': return { ...state, fontScale: action.scale };
    case 'SET_VIEW': return { ...state, viewMode: action.mode };
    case 'LOCK_DEAL': {
      const wallet = { ...state.wallet, inEscrow: state.wallet.inEscrow + action.txn.amount };
      return { ...state, transactions: [action.txn, ...state.transactions], wallet };
    }
    case 'CLEAR_DUES': {
      const wallet = { ...state.wallet, coldCredit: Math.max(0, state.wallet.coldCredit - action.amount) };
      const txn: AppState['transactions'][number] = {
        id: `TXN-${Date.now()}`, type: 'cold', description: 'Cold Storage Dues Paid via UPI',
        amount: action.amount, status: 'settled', utr: action.utr, date: new Date().toISOString().slice(0, 10),
      };
      const ledger: AppState['ledger'][number] = {
        id: `LED-${Date.now()}`, type: 'cold', description: 'Cold Storage Dues Paid via UPI',
        gross: action.amount, deductions: [], net: action.amount, status: 'settled', utr: action.utr,
        date: new Date().toISOString().slice(0, 10),
      };
      return { ...state, wallet, transactions: [txn, ...state.transactions], ledger: [ledger, ...state.ledger] };
    }
    case 'RESET': return { ...INITIAL_STATE };
    default: return state;
  }
}

const Ctx = createContext<{ state: AppState; dispatch: Dispatch<Action> } | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, loadState);

  useEffect(() => { saveState(state); }, [state]);
  useEffect(() => {
    document.documentElement.setAttribute('data-fontscale', state.fontScale);
  }, [state.fontScale]);

  return <Ctx.Provider value={{ state, dispatch }}>{children}</Ctx.Provider>;
}

export function useApp() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
