export interface IncomeResult {
  withoutFreshGrid: number;
  withFreshGrid: number;
  gainPct: number;
  gainAbs: number;
  withoutBreakdown: { label: string; amount: number }[];
  withBreakdown: { label: string; amount: number }[];
}

export function calcIncome(kg: number, pricePerKg: number, storageDays: number): IncomeResult {
  const gross = kg * pricePerKg;
  const spoilageLoss = Math.round(gross * 0.38);
  const mandiCommission = Math.round(gross * 0.06);
  const transportInd = kg * 4;
  const withoutFreshGrid = gross - spoilageLoss - mandiCommission - transportInd;

  const coldLoss = Math.round(gross * 0.08);
  const coldFee = storageDays * kg * 0.18;
  const pooledTransport = Math.round(kg * 1.5);
  const platformFee = Math.round(gross * 0.03);
  const withFreshGrid = gross - coldLoss - coldFee - pooledTransport - platformFee;

  const gainAbs = withFreshGrid - withoutFreshGrid;
  const gainPct = withoutFreshGrid > 0 ? Math.round((gainAbs / withoutFreshGrid) * 100) : 0;

  return {
    withoutFreshGrid,
    withFreshGrid,
    gainPct,
    gainAbs,
    withoutBreakdown: [
      { label: 'Gross Value', amount: gross },
      { label: 'Post-harvest spoilage (38%)', amount: -spoilageLoss },
      { label: 'Mandi middleman commission (6%)', amount: -mandiCommission },
      { label: 'Individual transport', amount: -transportInd },
    ],
    withBreakdown: [
      { label: 'Gross Value', amount: gross },
      { label: 'Spoilage with cold room (8%)', amount: -coldLoss },
      { label: 'Cold storage fee', amount: -Math.round(coldFee) },
      { label: 'Pooled FPO transport', amount: -pooledTransport },
      { label: 'Platform fee (3%)', amount: -platformFee },
    ],
  };
}

export function formatINR(n: number): string {
  const rounded = Math.round(n);
  const sign = rounded < 0 ? '-' : '';
  return `${sign}₹${Math.abs(rounded).toLocaleString('en-IN')}`;
}
